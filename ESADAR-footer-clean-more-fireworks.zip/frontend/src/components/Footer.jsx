import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext.jsx";
import esadarWordmark from "../assets/esadar-wordmark.png";

export default function Footer() {
  const { user } = useAuth();
  const isAdmin = user?.roles?.some((role) =>
    ["SUPER_ADMIN", "ADMIN", "OPERATOR"].includes(role),
  );

  return (
    <footer id="site-footer" className="site-footer">
      <div className="container footer-grid footer-grid-logo">
        <div className="footer-brand-block footer-brand-block--centered">
          <img
            src={esadarWordmark}
            alt="ESADAR"
            className="footer-logo-image"
          />

          <div className="footer-meta-row" aria-label="Información del sitio">
            <span className="footer-meta-copy">Mile y Fede ♥ sentados en un árbol</span>
            <span className="footer-meta-separator" aria-hidden="true">•</span>
            <Link to="/contact">Contacto</Link>
            <span className="footer-meta-separator" aria-hidden="true">•</span>
            <Link to="/about">Sobre nosotros</Link>
            {isAdmin ? (
              <>
                <span className="footer-meta-separator" aria-hidden="true">•</span>
                <Link to="/admin/articles">Administración</Link>
              </>
            ) : null}
            <span className="footer-meta-separator" aria-hidden="true">•</span>
            <a href="#top">Volver arriba</a>
          </div>
        </div>
      </div>

      <div className="footer-finale" aria-hidden="true">
        <img src={esadarWordmark} alt="" className="footer-finale__logo" />
      </div>
    </footer>
  );
}
