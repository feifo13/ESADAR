import { useEffect, useRef } from 'react';

export default function AdminPagination({
  page,
  totalPages,
  totalItems,
  loading,
  onPrevious,
  onNext,
  className = '',
}) {
  const sentinelRef = useRef(null);
  const canLoadMore = page < totalPages;
  const isTopPagination = className.includes('pagination-row--top');

  useEffect(() => {
    const sentinel = sentinelRef.current;
    if (!sentinel || isTopPagination || !canLoadMore || loading) return undefined;

    const observer = new IntersectionObserver(
      (entries) => {
        if (entries.some((entry) => entry.isIntersecting)) {
          onNext?.();
        }
      },
      { root: null, rootMargin: '360px 0px', threshold: 0.01 },
    );

    observer.observe(sentinel);
    return () => observer.disconnect();
  }, [canLoadMore, isTopPagination, loading, onNext, page, totalPages]);

  return (
    <div
      className={[
        'pagination-row',
        'pagination-row--infinite',
        isTopPagination ? 'pagination-row--status-only' : '',
        className,
      ].filter(Boolean).join(' ')}
    >
      <span className="muted-copy">
        Mostrando {Math.min(page, totalPages)} de {totalPages} tandas - {totalItems} registros
      </span>

      {!isTopPagination ? (
        <div ref={sentinelRef} className="infinite-scroll-sentinel" aria-live="polite">
          <span className="muted-copy">
            {loading
              ? 'Cargando mas registros…'
              : canLoadMore
                ? 'Desliza para cargar mas registros'
                : 'No hay mas registros para mostrar.'}
          </span>
        </div>
      ) : null}

      <div className="table-actions pagination-row__manual-actions" aria-hidden="true">
        <button
          type="button"
          className="button button-secondary"
          onClick={onPrevious}
          disabled={page === 1 || loading}
          tabIndex={-1}
        >
          Anterior
        </button>
        <button
          type="button"
          className="button button-secondary"
          onClick={onNext}
          disabled={page >= totalPages || loading}
          tabIndex={-1}
        >
          Siguiente
        </button>
      </div>
    </div>
  );
}
