ALTER TABLE company_collecting_settings
  ADD COLUMN IF NOT EXISTS mercado_pago_environment ENUM('test','production') NOT NULL DEFAULT 'test' AFTER is_mercado_pago_enabled,
  ADD COLUMN IF NOT EXISTS mercado_pago_notification_url VARCHAR(500) NULL AFTER mercado_pago_checkout_url;

UPDATE company_collecting_settings
SET mercado_pago_environment = COALESCE(NULLIF(mercado_pago_environment, ''), 'test')
WHERE id = 1;
