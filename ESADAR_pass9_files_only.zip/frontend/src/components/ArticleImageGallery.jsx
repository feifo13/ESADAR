import { useEffect, useMemo, useState } from 'react';
import ArticleImageZoom from './ArticleImageZoom.jsx';
import SmartImage from './SmartImage.jsx';

export default function ArticleImageGallery({ images = [], title, fallbackImage = null }) {
  const normalized = useMemo(() => {
    const fallback = fallbackImage || {};
    const fallbackSrc =
      fallback.detailFilePath ||
      fallback.detail_file_path ||
      fallback.primaryImageDetail ||
      fallback.primaryImage ||
      fallback.filePath ||
      fallback.file_path ||
      fallback.src ||
      '';
    const fallbackZoomSrc =
      fallback.zoomFilePath ||
      fallback.zoom_file_path ||
      fallbackSrc;
    const fallbackThumbSrc =
      fallback.thumbFilePath ||
      fallback.thumb_file_path ||
      fallback.primaryImageThumb ||
      fallback.cardFilePath ||
      fallback.card_file_path ||
      fallbackSrc;

    if (!images.length) {
      return [{
        id: 'fallback',
        src: fallbackSrc,
        zoomSrc: fallbackZoomSrc,
        thumbSrc: fallbackThumbSrc,
        altText: fallback.altText || fallback.primaryImageAlt || title,
        sources: [
          fallbackZoomSrc ? { srcSet: `${fallbackZoomSrc} 1600w`, media: '(min-width: 1280px)', type: 'image/webp' } : null,
          fallbackSrc ? { srcSet: `${fallbackSrc} 1100w`, media: '(min-width: 720px)', type: 'image/webp' } : null,
          fallbackThumbSrc ? { srcSet: `${fallbackThumbSrc} 700w`, type: 'image/webp' } : null,
        ].filter(Boolean),
      }];
    }

    return images.map((image, index) => {
      const detailSrc =
        image.detailFilePath ||
        image.detail_file_path ||
        image.filePath ||
        image.file_path ||
        image.src ||
        fallbackSrc;
      const zoomSrc =
        image.zoomFilePath ||
        image.zoom_file_path ||
        image.detailFilePath ||
        image.detail_file_path ||
        image.filePath ||
        image.file_path ||
        image.src ||
        fallbackZoomSrc;
      const thumbSrc =
        image.thumbFilePath ||
        image.thumb_file_path ||
        image.cardFilePath ||
        image.card_file_path ||
        image.filePath ||
        image.file_path ||
        image.src ||
        fallbackThumbSrc;

      return {
        id: image.id || index,
        src: detailSrc,
        zoomSrc,
        thumbSrc,
        altText: image.altText || image.alt_text || title,
        sources: [
          zoomSrc ? { srcSet: `${zoomSrc} 1600w`, media: '(min-width: 1280px)', type: 'image/webp' } : null,
          detailSrc ? { srcSet: `${detailSrc} 1100w`, media: '(min-width: 720px)', type: 'image/webp' } : null,
          thumbSrc ? { srcSet: `${thumbSrc} 700w`, type: 'image/webp' } : null,
        ].filter(Boolean),
      };
    });
  }, [fallbackImage, images, title]);

  const [activeIndex, setActiveIndex] = useState(0);
  const active = normalized[activeIndex] || normalized[0];

  useEffect(() => {
    setActiveIndex(0);
  }, [normalized.length]);

  useEffect(() => {
    function handleKeydown(event) {
      if (event.key === 'ArrowLeft') {
        setActiveIndex((current) => (current - 1 + normalized.length) % normalized.length);
      }

      if (event.key === 'ArrowRight') {
        setActiveIndex((current) => (current + 1) % normalized.length);
      }
    }

    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [normalized.length]);

  return (
    <div className={normalized.length > 1 ? 'article-gallery-layout' : 'article-gallery-layout article-gallery-layout--single'}>
      {normalized.length > 1 ? (
        <div className="article-gallery-thumbs" tabIndex={0} aria-label="Miniaturas del articulo">
          {normalized.map((image, index) => (
            <button
              type="button"
              key={image.id}
              className={index === activeIndex ? 'article-gallery-thumb is-active' : 'article-gallery-thumb'}
              aria-label={`Ver imagen ${index + 1} de ${normalized.length}`}
              onClick={() => setActiveIndex(index)}
            >
              <SmartImage
                src={image.thumbSrc || image.src}
                alt={`${title} ${index + 1}`}
                fallbackLabel={title}
                className="article-gallery-thumb__image"
              />
            </button>
          ))}
        </div>
      ) : null}

      <div className="article-gallery-main">
        <div className="gallery-count" aria-live="polite">{activeIndex + 1} / {normalized.length}</div>
        <ArticleImageZoom image={active} title={title} />
      </div>
    </div>
  );
}
