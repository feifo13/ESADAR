import { Outlet, useLocation } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Header from './Header.jsx';
import Footer from './Footer.jsx';
import ThemeDock from './ThemeDock.jsx';
import ScrollChrome from './ScrollChrome.jsx';
import esadarWordmark from '../assets/esadar-wordmark.png';

const INTRO_VISIBLE_MS = 2650;
const INTRO_FADE_MS = 650;

export default function RootLayout() {
  const location = useLocation();
  const [heroLogoVisible, setHeroLogoVisible] = useState(false);
  const [introStage, setIntroStage] = useState('visible');
  const isHome = location.pathname === '/';
  const isCheckoutView = location.pathname.startsWith('/checkout');
  const isAdminView = location.pathname.startsWith('/admin');

  useEffect(() => {
    setIntroStage('visible');

    const reduceMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    if (reduceMotion) {
      setIntroStage('hidden');
      return undefined;
    }

    const fadeTimer = window.setTimeout(() => setIntroStage('fading'), INTRO_VISIBLE_MS);
    const hideTimer = window.setTimeout(() => setIntroStage('hidden'), INTRO_VISIBLE_MS + INTRO_FADE_MS);

    return () => {
      window.clearTimeout(fadeTimer);
      window.clearTimeout(hideTimer);
    };
  }, []);

  const showIntro = introStage !== 'hidden';

  return (
    <div
      className={`app-shell${showIntro ? ' app-shell--intro-active' : ''}${isCheckoutView ? ' app-shell--checkout-view' : ''}${isAdminView ? ' app-shell--admin-view' : ''}`}
    >
      <Header hideBrand={isHome && heroLogoVisible} />
      <main className="page-shell">
        <div key={location.pathname} className="page-transition-shell">
          <Outlet context={{ setHeroLogoVisible }} />
        </div>
      </main>
      <Footer />
      <ThemeDock />
      <ScrollChrome />

      {showIntro ? (
        <div
          className={`intro-splash${introStage === 'fading' ? ' intro-splash--fade-out' : ''}`}
          aria-hidden="true"
        >
          <div className="intro-splash__logo-wrap">
            <img src={esadarWordmark} alt="" className="intro-splash__logo" />
          </div>
        </div>
      ) : null}
    </div>
  );
}
