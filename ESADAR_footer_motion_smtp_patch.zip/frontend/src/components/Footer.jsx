import { Link } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext.jsx";
import esadarWordmark from "../assets/esadar-wordmark.png";

export default function Footer() {
  const { user } = useAuth();
  const isAdmin = user?.roles?.some((role) =>
    ["SUPER_ADMIN", "ADMIN", "OPERATOR"].includes(role),
  );

  return (
    <>
      <section className="footer-brand-section" aria-label="Marca ESADAR">
        <div className="container footer-brand-section__inner">
          <img
            src={esadarWordmark}
            alt="ESADAR"
            className="footer-brand-section__logo"
          />
          <p className="footer-brand-section__copy">
            Mile y Fede ♥ sentados en un arbol
          </p>
        </div>
      </section>

      <footer className="site-footer">
        <div className="container footer-grid footer-grid-nav">
          <div>
            <p className="footer-title">Navegación</p>
            <div className="footer-links">
              <Link to="/contact">Contacto</Link>
              <Link to="/about">Sobre nosotros</Link>
              {isAdmin ? <Link to="/admin/articles">Administración</Link> : null}
              <a href="#top">Volver arriba</a>
            </div>
          </div>

          <div>
            <p className="footer-title">Firma</p>
            <p className="footer-copy">B-E-S-A-N-D-O-S-E</p>
          </div>
        </div>
      </footer>
    </>
  );
}
