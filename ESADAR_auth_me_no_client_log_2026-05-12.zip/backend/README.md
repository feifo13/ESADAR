# ESADAR Backend

Backend base en Express + MySQL para la tienda curada de segunda mano.

## Incluye

- Auth con JWT (`login`, `register`, `me`)
- Listado público y detalle de artículos
- CRUD base de artículos para backoffice
- Subida de imágenes de artículos
- Creación de órdenes con reserva de stock por 24h
- Acciones backoffice sobre órdenes (`approve`, `cancel`, `ship`)
- Auditoría central en `audit_log`

## Requisitos

- Node 20+
- MySQL con el schema y seed ya importados

## Instalación

```bash
npm install
cp .env.example .env
npm run dev
```

## Variables de entorno

Ver `.env.example`.

## Rutas principales

### Health
- `GET /api/health`

### Auth
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/auth/me`

### Artículos públicos
- `GET /api/public/articles`
- `GET /api/public/articles/:slugOrId`

### Artículos backoffice
- `GET /api/admin/articles`
- `GET /api/admin/articles/:id`
- `POST /api/admin/articles`
- `PUT /api/admin/articles/:id`
- `PATCH /api/admin/articles/:id/status`
- `POST /api/admin/articles/:id/images`

### Órdenes
- `POST /api/public/orders`
- `GET /api/admin/orders`
- `GET /api/admin/orders/:id`
- `PATCH /api/admin/orders/:id/approve`
- `PATCH /api/admin/orders/:id/cancel`
- `PATCH /api/admin/orders/:id/ship`

### Auditoría
- `GET /api/admin/audit`

## Roles esperados

- `SUPER_ADMIN`
- `ADMIN`
- `OPERATOR`
- `CUSTOMER`

## Notas

- La lógica de auditoría escribe en `audit_log`.
- La creación de órdenes reserva stock inmediatamente por 24 horas.
- El checkout soporta usuario autenticado o comprador invitado.
- Las ofertas no están implementadas aún en este starter, pero la estructura ya queda preparada para el siguiente paso.

## Emails ESADAR

El backend centraliza los correos de marca en `src/modules/mail/`.

Variables sugeridas para producción:

```env
PUBLIC_SITE_URL=https://tudominio.com
EMAIL_LOGO_URL=https://tudominio.com/assets/esadar-logo.png
```

El logo público queda disponible desde `/assets/esadar-logo.png`. Las imágenes de artículos en correos se envían como URLs absolutas y dependen de que `PUBLIC_SITE_URL` apunte a un dominio accesible desde Gmail.

Pruebas manuales sugeridas:

- Registro de usuario: `POST /api/auth/register` debe enviar bienvenida sin romper el registro si SMTP falla.
- Recuperar contraseña: `POST /api/auth/forgot-password` debe enviar reset password con el template nuevo y mantener validación obligatoria de SMTP.
- Oferta aceptada: cambiar una oferta a `ACCEPTED` desde admin debe enviar el mail de oferta aceptada.
- Orden aprobada: aprobar una orden desde admin debe enviar el mail de orden aprobada sin romper la aprobación si SMTP falla.
- Respuesta de contacto: responder un mensaje debe enviar el mail y marcarlo como `REPLIED` solo si SMTP funciona.

Branch local recomendado para estos cambios:

```bash
git switch -c feature/esadar-email-templates
git status
git add .
git commit -m "feat: add branded email templates and dynamic mailers"
```

## ESADAR emails en local: logo y gradiente inline

Para que Gmail muestre el logo y la banda `email-brand-gradient.png` aunque el backend esté corriendo en local, los mails de marca usan imágenes inline CID por defecto. Esto evita depender de URLs `localhost`, que Gmail no puede resolver desde fuera de tu PC.

Assets usados por los templates:

```text
backend/public/assets/esadar-logo.png
backend/public/assets/email-brand-gradient.png
```

El backend también sigue sirviéndolos en `/assets` para producción o pruebas con dominio público/ngrok.

Variables opcionales:

```env
# Por defecto se usa CID inline. Para forzar URLs públicas externas:
EMAIL_ASSETS_MODE=external
PUBLIC_SITE_URL=https://tudominio.com
EMAIL_LOGO_URL=https://tudominio.com/assets/esadar-logo.png
EMAIL_BRAND_GRADIENT_URL=https://tudominio.com/assets/email-brand-gradient.png
```
