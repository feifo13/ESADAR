import { env } from "../../../config/env.js";
import { escapeHtml } from "../mail.escape.js";
import { getArticleEmailImageUrl } from "../mail.assets.js";
import { buildCustomerName, formatCurrencyUYU } from "../mail.format.js";
import { renderEmailShell } from "./base-shell.js";

function renderButton(url, label) {
  return `
    <table role="presentation" cellspacing="0" cellpadding="0" border="0" style="margin-top:24px;">
      <tr>
        <td>
          <a href="${escapeHtml(url)}" class="email-button" target="_blank" style="display:inline-block; padding:13px 22px; background:#008e97; color:#ffffff; text-decoration:none; font-weight:700; border:1px solid #008e97;">${escapeHtml(label)}</a>
        </td>
      </tr>
    </table>
  `;
}

function renderSummaryRow(label, value, options = {}) {
  if (!value && value !== 0) return "";
  return `
    <tr>
      <td style="padding:4px 0; color:#56737a; font-size:14px;">${escapeHtml(label)}</td>
      <td align="right" style="padding:4px 0; color:${options.accent ? "#008e97" : "#102b34"}; font-size:${options.large ? "20px" : "14px"}; font-weight:700;">${escapeHtml(value)}</td>
    </tr>
  `;
}

function renderOrderItems(items = []) {
  const visibleItems = items.slice(0, 3);
  if (!visibleItems.length) return "";

  const rows = visibleItems
    .map((item) => {
      const title = item.articleTitle || item.title || "Prenda";
      const quantity = Number(item.quantity || 1);
      const lineTotal = formatCurrencyUYU(item.lineTotal, item.currencyCode || "UYU");
      const imageUrl = getArticleEmailImageUrl(item.image || item.imageSnapshot || item);
      const imageCell = imageUrl
        ? `<td style="padding:10px 12px 10px 0; width:58px;" valign="top"><img class="email-item-image" src="${escapeHtml(imageUrl)}" width="52" height="52" alt="${escapeHtml(title)}" style="display:block; width:52px; height:52px; object-fit:cover; border:0; outline:none; text-decoration:none;" /></td>`
        : "";

      return `
        <tr>
          ${imageCell}
          <td style="padding:10px 0; border-top:1px solid rgba(16,43,52,0.10); color:#102b34; font-size:14px; line-height:1.45;" valign="middle">
            <strong>${escapeHtml(title)}</strong><br />
            <span style="color:#56737a;">Cantidad: ${escapeHtml(quantity)}</span>
          </td>
          <td align="right" style="padding:10px 0 10px 12px; border-top:1px solid rgba(16,43,52,0.10); color:#102b34; font-size:14px; font-weight:700; white-space:nowrap;" valign="middle">${escapeHtml(lineTotal)}</td>
        </tr>
      `;
    })
    .join("");

  return `
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin:22px 0; background:#ffffff; border:1px solid rgba(16,43,52,0.12);">
      <tr>
        <td style="padding:14px 16px 6px; color:#102b34; font-size:15px; font-weight:700;">Prendas de la orden</td>
      </tr>
      <tr>
        <td style="padding:0 16px 12px;">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0">${rows}</table>
        </td>
      </tr>
    </table>
  `;
}

function renderPaymentInstructions(paymentInstructions) {
  if (!paymentInstructions) return "";

  const fields = Array.isArray(paymentInstructions.fields)
    ? paymentInstructions.fields.filter((field) => field?.value)
    : [];
  const hasInstructions = Boolean(paymentInstructions.instructions);
  if (!fields.length && !hasInstructions) return "";

  const rows = fields
    .map(
      (field) => `
        <tr>
          <td style="padding:5px 0; color:#56737a; font-size:14px;">${escapeHtml(field.label)}</td>
          <td align="right" style="padding:5px 0; color:#102b34; font-size:14px; font-weight:700; word-break:break-word;">${escapeHtml(field.value)}</td>
        </tr>
      `,
    )
    .join("");

  const instructionsHtml = hasInstructions
    ? `<p style="margin:12px 0 0; color:#56737a; font-size:14px; line-height:1.55;">${escapeHtml(paymentInstructions.instructions).replace(/\n/g, "<br />")}</p>`
    : "";

  return `
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin:22px 0; background:#ffffff; border:1px solid rgba(16,43,52,0.14);">
      <tr>
        <td style="padding:16px 18px;">
          <p style="margin:0 0 10px; color:#008e97; font-size:12px; font-weight:700; letter-spacing:0.08em; text-transform:uppercase;">${escapeHtml(paymentInstructions.title || "Datos de pago")}</p>
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" class="email-meta-table">
            ${rows}
          </table>
          ${instructionsHtml}
        </td>
      </tr>
    </table>
  `;
}

function formatPaymentInstructionLines(paymentInstructions) {
  if (!paymentInstructions) return [];
  const lines = [];
  const fields = Array.isArray(paymentInstructions.fields)
    ? paymentInstructions.fields.filter((field) => field?.value)
    : [];

  if (!fields.length && !paymentInstructions.instructions) return lines;

  lines.push("", paymentInstructions.title || "Datos de pago");
  fields.forEach((field) => lines.push(`${field.label}: ${field.value}`));
  if (paymentInstructions.instructions) {
    lines.push(String(paymentInstructions.instructions));
  }
  return lines;
}

export function renderReceivedOrderPendingPaymentEmail({ order } = {}) {
  const name = buildCustomerName(order?.customer);
  const orderLabel = order?.orderNumber || order?.id || "";
  const orderUrl = `${env.publicSiteUrl}/cuenta/ordenes${order?.id ? `/${order.id}` : ""}`;
  const total = formatCurrencyUYU(order?.total, order?.currencyCode || "UYU");
  const paymentMethod = order?.paymentMethod || "";
  const shippingMethod = order?.shippingMethodDescription || "";
  const paymentInstructions = order?.paymentInstructions || null;
  const subject = `Recibimos tu orden - Pago pendiente`;
  const preheader = "Recibimos tu orden y reservamos tus prendas por 24 horas.";

  const textLines = [
    `Hola ${name},`,
    "",
    "Recibimos tu orden en ESADAR.",
    "La recepción del pago está pendiente.",
    "Reservamos tu orden por 24 horas.",
    "",
    `Orden: ${orderLabel}`,
    `Total: ${total}`,
    "Estado: Pago pendiente",
  ];
  if (paymentMethod) textLines.push(`Método de pago: ${paymentMethod}`);
  if (shippingMethod) textLines.push(`Método de envío: ${shippingMethod}`);
  textLines.push(...formatPaymentInstructionLines(paymentInstructions));
  textLines.push("", "Adjuntamos la boleta de tu orden en PDF.", "Podés revisar los detalles desde tu cuenta.", orderUrl, "", "Equipo ESADAR");

  const bodyHtml = `
    <p style="margin:0 0 14px;">Hola ${escapeHtml(name)},</p>
    <p style="margin:0 0 14px;">Recibimos tu orden en <strong style="color:#102b34;">ESADAR</strong>.</p>
    <p style="margin:0 0 14px;">La recepción del pago está <strong style="color:#102b34;">pendiente</strong>.</p>
    <p style="margin:0 0 18px;">Reservamos tu orden por <strong style="color:#102b34;">24 horas</strong>.</p>
  `;

  const detailsHtml = `
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="margin:22px 0; background:#eef4f5; border:1px solid rgba(16,43,52,0.12);">
      <tr>
        <td style="padding:18px;">
          <table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" class="email-meta-table">
            ${renderSummaryRow("Orden", orderLabel)}
            ${renderSummaryRow("Total", total, { large: true })}
            ${renderSummaryRow("Estado", "Pago pendiente", { accent: true })}
            ${renderSummaryRow("Método de pago", paymentMethod)}
            ${renderSummaryRow("Método de envío", shippingMethod)}
          </table>
        </td>
      </tr>
    </table>
    ${renderPaymentInstructions(paymentInstructions)}
    ${renderOrderItems(order?.items || [])}
  `;

  return {
    subject,
    preheader,
    text: textLines.join("\n"),
    html: renderEmailShell({
      subject,
      preheader,
      eyebrow: "ORDEN RECIBIDA",
      title: "Recibimos tu orden",
      bodyHtml,
      detailsHtml,
      ctaHtml: renderButton(orderUrl, "Ver mi orden"),
    }),
  };
}
