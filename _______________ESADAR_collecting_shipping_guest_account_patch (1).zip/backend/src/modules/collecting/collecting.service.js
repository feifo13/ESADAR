import { pool } from '../../db/pool.js';
import { withTransaction } from '../../db/transaction.js';
import { logAudit } from '../audit/audit.service.js';

function clean(value) {
  if (value == null) return null;
  const text = String(value).trim();
  return text || null;
}

function bool(value, fallback = false) {
  if (value == null) return fallback;
  return Boolean(Number(value));
}

function normalizeSettingsRow(row = {}) {
  return {
    id: Number(row.id || 1),
    isBankTransferEnabled: bool(row.isBankTransferEnabled, true),
    bankAccountHolder: row.bankAccountHolder || '',
    bankName: row.bankName || '',
    bankAccountType: row.bankAccountType || '',
    bankAccountNumber: row.bankAccountNumber || '',
    bankBranch: row.bankBranch || '',
    bankCurrency: row.bankCurrency || 'UYU',
    bankAlias: row.bankAlias || '',
    bankDocument: row.bankDocument || '',
    bankInstructions: row.bankInstructions || '',
    isMercadoPagoEnabled: bool(row.isMercadoPagoEnabled, true),
    mercadoPagoPublicKey: row.mercadoPagoPublicKey || '',
    mercadoPagoAccessToken: row.mercadoPagoAccessToken || '',
    mercadoPagoUserId: row.mercadoPagoUserId || '',
    mercadoPagoCheckoutUrl: row.mercadoPagoCheckoutUrl || '',
    mercadoPagoPreferenceNote: row.mercadoPagoPreferenceNote || '',
    mercadoPagoInstructions: row.mercadoPagoInstructions || '',
    createdAt: row.createdAt || null,
    updatedAt: row.updatedAt || null,
  };
}

function normalizeSettingsForAudit(settings) {
  if (!settings) return null;
  return {
    ...settings,
    mercadoPagoAccessToken: settings.mercadoPagoAccessToken ? '[configured]' : '',
  };
}

async function ensureSettingsRow(connection = pool) {
  await connection.execute(
    `
      INSERT INTO company_collecting_settings (id, bank_currency)
      VALUES (1, 'UYU')
      ON DUPLICATE KEY UPDATE id = id
    `,
  );
}

export async function getCollectingSettings(connection = pool) {
  await ensureSettingsRow(connection);
  const [rows] = await connection.execute(
    `
      SELECT
        id,
        is_bank_transfer_enabled AS isBankTransferEnabled,
        bank_account_holder AS bankAccountHolder,
        bank_name AS bankName,
        bank_account_type AS bankAccountType,
        bank_account_number AS bankAccountNumber,
        bank_branch AS bankBranch,
        bank_currency AS bankCurrency,
        bank_alias AS bankAlias,
        bank_document AS bankDocument,
        bank_instructions AS bankInstructions,
        is_mercado_pago_enabled AS isMercadoPagoEnabled,
        mercado_pago_public_key AS mercadoPagoPublicKey,
        mercado_pago_access_token AS mercadoPagoAccessToken,
        mercado_pago_user_id AS mercadoPagoUserId,
        mercado_pago_checkout_url AS mercadoPagoCheckoutUrl,
        mercado_pago_preference_note AS mercadoPagoPreferenceNote,
        mercado_pago_instructions AS mercadoPagoInstructions,
        created_at AS createdAt,
        updated_at AS updatedAt
      FROM company_collecting_settings
      WHERE id = 1
      LIMIT 1
    `,
  );

  return normalizeSettingsRow(rows[0] || { id: 1 });
}

export async function updateCollectingSettings(input, auditContext) {
  return withTransaction(async (connection) => {
    const before = await getCollectingSettings(connection);

    await connection.execute(
      `
        UPDATE company_collecting_settings
        SET
          is_bank_transfer_enabled = ?,
          bank_account_holder = ?,
          bank_name = ?,
          bank_account_type = ?,
          bank_account_number = ?,
          bank_branch = ?,
          bank_currency = ?,
          bank_alias = ?,
          bank_document = ?,
          bank_instructions = ?,
          is_mercado_pago_enabled = ?,
          mercado_pago_public_key = ?,
          mercado_pago_access_token = ?,
          mercado_pago_user_id = ?,
          mercado_pago_checkout_url = ?,
          mercado_pago_preference_note = ?,
          mercado_pago_instructions = ?,
          updated_by = ?
        WHERE id = 1
      `,
      [
        input.isBankTransferEnabled ? 1 : 0,
        clean(input.bankAccountHolder),
        clean(input.bankName),
        clean(input.bankAccountType),
        clean(input.bankAccountNumber),
        clean(input.bankBranch),
        clean(input.bankCurrency) || 'UYU',
        clean(input.bankAlias),
        clean(input.bankDocument),
        clean(input.bankInstructions),
        input.isMercadoPagoEnabled ? 1 : 0,
        clean(input.mercadoPagoPublicKey),
        clean(input.mercadoPagoAccessToken),
        clean(input.mercadoPagoUserId),
        clean(input.mercadoPagoCheckoutUrl),
        clean(input.mercadoPagoPreferenceNote),
        clean(input.mercadoPagoInstructions),
        auditContext.actorUserId || null,
      ],
    );

    const after = await getCollectingSettings(connection);

    await logAudit(
      {
        actorUserId: auditContext.actorUserId,
        actorLabel: auditContext.actorLabel,
        actionCode: 'COLLECTING_SETTINGS_UPDATED',
        entityType: 'company_collecting_settings',
        entityId: 1,
        beforeJson: normalizeSettingsForAudit(before),
        afterJson: normalizeSettingsForAudit(after),
        source: auditContext.source,
        ipAddress: auditContext.ipAddress,
        userAgent: auditContext.userAgent,
      },
      connection,
    );

    return after;
  });
}

function buildBankTransferDetails(settings) {
  const fields = [
    ['Titular', settings.bankAccountHolder],
    ['Banco', settings.bankName],
    ['Tipo de cuenta', settings.bankAccountType],
    ['Numero de cuenta', settings.bankAccountNumber],
    ['Sucursal', settings.bankBranch],
    ['Moneda', settings.bankCurrency],
    ['Alias', settings.bankAlias],
    ['Documento/RUT', settings.bankDocument],
  ]
    .filter(([, value]) => clean(value))
    .map(([label, value]) => ({ label, value: clean(value) }));

  return {
    method: 'BANK_TRANSFER',
    label: 'Transferencia bancaria',
    title: 'Datos para transferencia bancaria',
    enabled: settings.isBankTransferEnabled,
    fields,
    instructions: clean(settings.bankInstructions),
  };
}

function buildMercadoPagoDetails(settings) {
  const fields = [
    ['Link de pago', settings.mercadoPagoCheckoutUrl],
    ['Usuario / Collector ID', settings.mercadoPagoUserId],
    ['Referencia', settings.mercadoPagoPreferenceNote],
  ]
    .filter(([, value]) => clean(value))
    .map(([label, value]) => ({ label, value: clean(value) }));

  return {
    method: 'MERCADO_PAGO',
    label: 'Mercado Pago',
    title: 'Datos para pagar con Mercado Pago',
    enabled: settings.isMercadoPagoEnabled,
    fields,
    instructions: clean(settings.mercadoPagoInstructions),
    checkoutUrl: clean(settings.mercadoPagoCheckoutUrl),
  };
}

export async function getPaymentInstructionsForMethod(paymentMethod, connection = pool) {
  const settings = await getCollectingSettings(connection);
  if (paymentMethod === 'BANK_TRANSFER') return buildBankTransferDetails(settings);
  if (paymentMethod === 'MERCADO_PAGO') return buildMercadoPagoDetails(settings);

  return {
    method: paymentMethod || '',
    label: paymentMethod || 'Metodo de pago',
    title: 'Datos de pago',
    enabled: true,
    fields: [],
    instructions: null,
  };
}
