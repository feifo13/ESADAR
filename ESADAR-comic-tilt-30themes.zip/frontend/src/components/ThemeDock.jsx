import { useState } from 'react';
import { useTheme } from '../contexts/ThemeContext.jsx';
import { storage } from '../lib/storage.js';

const DOCK_HIDDEN_KEY = 'esadar-theme-dock-hidden';

export default function ThemeDock() {
  const { theme, setTheme, themeOptions } = useTheme();
  const [isHidden, setIsHidden] = useState(() => storage.get(DOCK_HIDDEN_KEY, false));
  const currentTheme = themeOptions.find((option) => option.id === theme);

  function handleHide() {
    storage.set(DOCK_HIDDEN_KEY, true);
    setIsHidden(true);
  }

  function handleShow() {
    storage.set(DOCK_HIDDEN_KEY, false);
    setIsHidden(false);
  }

  if (isHidden) {
    return (
      <button type="button" className="theme-dock-reveal" onClick={handleShow} aria-label="Mostrar selector de themes">
        Themes
      </button>
    );
  }

  return (
    <aside className="theme-dock" aria-label="Selector de paleta">
      <div className="theme-dock-header">
        <div>
          <div className="theme-dock-label">Themes</div>
          <div className="theme-dock-current">{currentTheme?.label || 'Default'}</div>
        </div>
        <button type="button" className="theme-dock-hide" onClick={handleHide}>
          Ocultar
        </button>
      </div>

      <div className="theme-dock-buttons">
        {themeOptions.map((option) => (
          <button
            key={option.id}
            type="button"
            className={theme === option.id ? 'theme-swatch active' : 'theme-swatch'}
            onClick={() => setTheme(option.id)}
            title={option.label}
            aria-label={option.label}
          >
            {option.swatch.map((color) => (
              <span key={color} style={{ background: color }} />
            ))}
          </button>
        ))}
      </div>
    </aside>
  );
}
