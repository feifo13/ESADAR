import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { storage } from '../lib/storage.js';
import { THEME_DEFINITIONS, THEME_IDS, THEME_MAP } from '../constants/themes.js';

const ThemeContext = createContext(null);
const THEME_STORAGE_KEY = 'miami-closet-theme';
const THEME_VAR_KEYS = [
  'bg',
  'surface',
  'surface-soft',
  'text',
  'muted',
  'border',
  'aqua',
  'orange',
  'navy',
  'comic-dot',
  'comic-line',
  'comic-shadow',
  'comic-ink',
];

function normalizeTheme(rawTheme) {
  if (rawTheme === 'alt') return 'marine';
  if (THEME_IDS.includes(rawTheme)) return rawTheme;
  return 'default';
}

export function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(() => normalizeTheme(storage.get(THEME_STORAGE_KEY, 'default')));

  function setTheme(nextTheme) {
    setThemeState(normalizeTheme(nextTheme));
  }

  useEffect(() => {
    const root = document.documentElement;
    const definition = THEME_MAP[theme] || THEME_MAP.default;

    root.dataset.theme = theme;
    root.style.colorScheme = definition.mode;

    THEME_VAR_KEYS.forEach((key) => {
      const value = definition.vars[key];
      if (value) {
        root.style.setProperty(`--${key}`, value);
      } else {
        root.style.removeProperty(`--${key}`);
      }
    });

    storage.set(THEME_STORAGE_KEY, theme);
  }, [theme]);

  const value = useMemo(
    () => ({
      theme,
      themeOptions: THEME_DEFINITIONS,
      themes: THEME_IDS,
      setTheme,
      cycleTheme: () => {
        const currentIndex = THEME_IDS.indexOf(theme);
        const nextIndex = (currentIndex + 1) % THEME_IDS.length;
        setTheme(THEME_IDS[nextIndex]);
      },
    }),
    [theme],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used inside ThemeProvider');
  return context;
}
