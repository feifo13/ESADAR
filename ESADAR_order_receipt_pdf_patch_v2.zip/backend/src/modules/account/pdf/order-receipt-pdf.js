import fs from 'node:fs';
import path from 'node:path';
import PDFDocument from 'pdfkit';
import { env } from '../../../config/env.js';

const PAGE = { width: 720, height: 960, margin: 30 };

const COLORS = {
  navy: '#08265a',
  navySoft: '#23447d',
  aqua: '#20b8c7',
  aquaSoft: '#edf9fb',
  orange: '#ff5a00',
  border: '#8aa3c9',
  text: '#0d244f',
  muted: '#667899',
  white: '#ffffff',
};

const LOGO_PATH = path.resolve(new URL('../../../assets/esadar-logo.png', import.meta.url).pathname);

const PAYMENT_METHOD_LABELS = {
  BANK_TRANSFER: 'Transferencia bancaria',
  MERCADO_PAGO: 'Mercado Pago',
};

const PAYMENT_STATUS_LABELS = {
  PENDING: 'Pago pendiente',
  APPROVED: 'Pago aprobado',
  REJECTED: 'Pago rechazado',
  FAILED: 'Pago fallido',
  REFUNDED: 'Pago reintegrado',
  PAID: 'Pago aprobado',
};

function asNumber(value) {
  const parsed = Number(value ?? 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function clean(value, fallback = '-') {
  if (value == null) return fallback;
  const text = String(value).trim();
  return text || fallback;
}

function fullName(customer = {}) {
  return [customer.firstName, customer.lastName]
    .map((part) => clean(part, ''))
    .filter(Boolean)
    .join(' ') || '-';
}

function formatCurrency(value) {
  return new Intl.NumberFormat('es-UY', {
    style: 'currency',
    currency: 'UYU',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(asNumber(value));
}

function pad(value) {
  return String(value).padStart(2, '0');
}

function formatDateParts(value) {
  if (!value) return { date: '-', time: '-' };
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return { date: '-', time: '-' };
  return {
    date: `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()}`,
    time: `${pad(date.getHours())}:${pad(date.getMinutes())} hs`,
  };
}

function websiteLabel(url) {
  const normalized = clean(url || '', '').replace(/^https?:\/\//i, '').replace(/\/$/, '');
  if (!normalized || /localhost|127\.0\.0\.1/i.test(normalized)) return 'www.esadar.com.ar';
  return normalized;
}

function drawText(doc, value, x, y, options = {}) {
  doc
    .font(options.bold ? 'Helvetica-Bold' : 'Helvetica')
    .fontSize(options.size || 10)
    .fillColor(options.color || COLORS.text)
    .text(clean(value, options.fallback || ''), x, y, {
      width: options.width,
      align: options.align || 'left',
      lineGap: options.lineGap || 0,
      height: options.height,
      ellipsis: options.ellipsis || false,
      continued: options.continued || false,
    });
}

function drawRect(doc, x, y, w, h, options = {}) {
  doc.save();
  if (options.fill) {
    doc.rect(x, y, w, h).fill(options.fill);
  }
  doc
    .rect(x, y, w, h)
    .lineWidth(options.lineWidth || 0.8)
    .stroke(options.stroke || COLORS.border);
  doc.restore();
}

function drawHLine(doc, x1, y, x2, color = COLORS.border, lineWidth = 0.8) {
  doc.save().strokeColor(color).lineWidth(lineWidth).moveTo(x1, y).lineTo(x2, y).stroke().restore();
}

function drawVLine(doc, x, y1, y2, color = COLORS.border, lineWidth = 0.8) {
  doc.save().strokeColor(color).lineWidth(lineWidth).moveTo(x, y1).lineTo(x, y2).stroke().restore();
}

function drawSimpleIcon(doc, kind, x, y, color = COLORS.aqua) {
  doc.save().strokeColor(color).fillColor(color).lineWidth(1.7);

  if (kind === 'order') {
    doc.rect(x, y + 4, 22, 24).stroke();
    doc.moveTo(x + 6, y + 4).lineTo(x + 6, y).lineTo(x + 16, y).lineTo(x + 16, y + 4).stroke();
    doc.circle(x + 11, y + 16, 4).stroke();
  } else if (kind === 'date') {
    doc.rect(x, y + 5, 25, 23).stroke();
    doc.moveTo(x, y + 12).lineTo(x + 25, y + 12).stroke();
    doc.moveTo(x + 7, y).lineTo(x + 7, y + 8).stroke();
    doc.moveTo(x + 18, y).lineTo(x + 18, y + 8).stroke();
  } else if (kind === 'cart') {
    doc.moveTo(x, y + 6).lineTo(x + 4, y + 6).lineTo(x + 8, y + 21).lineTo(x + 24, y + 21).stroke();
    doc.moveTo(x + 7, y + 11).lineTo(x + 24, y + 11).lineTo(x + 21, y + 18).stroke();
    doc.circle(x + 10, y + 27, 2).stroke();
    doc.circle(x + 22, y + 27, 2).stroke();
  } else if (kind === 'person') {
    doc.circle(x + 11, y + 7, 4).stroke();
    doc.moveTo(x + 3, y + 24).bezierCurveTo(x + 6, y + 15, x + 16, y + 15, x + 19, y + 24).stroke();
  } else if (kind === 'mail') {
    doc.rect(x, y + 5, 22, 16).stroke();
    doc.moveTo(x, y + 5).lineTo(x + 11, y + 14).lineTo(x + 22, y + 5).stroke();
  } else if (kind === 'phone') {
    doc.moveTo(x + 4, y + 3).bezierCurveTo(x + 1, y + 9, x + 6, y + 20, x + 12, y + 24).stroke();
    doc.moveTo(x + 12, y + 24).bezierCurveTo(x + 16, y + 27, x + 20, y + 25, x + 22, y + 20).stroke();
    doc.moveTo(x + 6, y + 7).lineTo(x + 10, y + 10).stroke();
    doc.moveTo(x + 15, y + 18).lineTo(x + 19, y + 21).stroke();
  } else if (kind === 'pin') {
    doc.circle(x + 11, y + 8, 5).stroke();
    doc.moveTo(x + 11, y + 13).lineTo(x + 11, y + 26).stroke();
    doc.moveTo(x + 7, y + 20).lineTo(x + 11, y + 26).lineTo(x + 15, y + 20).stroke();
  } else if (kind === 'home') {
    doc.moveTo(x + 1, y + 12).lineTo(x + 11, y + 3).lineTo(x + 21, y + 12).stroke();
    doc.rect(x + 4, y + 12, 14, 12).stroke();
  } else if (kind === 'clock') {
    doc.circle(x + 11, y + 14, 9).stroke();
    doc.moveTo(x + 11, y + 14).lineTo(x + 11, y + 9).stroke();
    doc.moveTo(x + 11, y + 14).lineTo(x + 15, y + 16).stroke();
  } else if (kind === 'card') {
    doc.rect(x, y + 5, 28, 20).stroke();
    doc.moveTo(x, y + 12).lineTo(x + 28, y + 12).stroke();
  } else if (kind === 'shield') {
    doc.moveTo(x + 12, y + 2).lineTo(x + 22, y + 6).lineTo(x + 20, y + 18).lineTo(x + 12, y + 24).lineTo(x + 4, y + 18).lineTo(x + 2, y + 6).closePath().stroke();
    doc.moveTo(x + 8, y + 12).lineTo(x + 11, y + 15).lineTo(x + 16, y + 9).stroke();
  } else if (kind === 'tag') {
    doc.polygon([x + 3, y + 3], [x + 17, y + 3], [x + 25, y + 11], [x + 12, y + 24], [x + 3, y + 15]).stroke();
    doc.circle(x + 12, y + 9, 1.7).stroke();
  } else if (kind === 'truck') {
    doc.rect(x, y + 10, 16, 10).stroke();
    doc.rect(x + 16, y + 13, 10, 7).stroke();
    doc.circle(x + 6, y + 22, 2).stroke();
    doc.circle(x + 20, y + 22, 2).stroke();
  } else if (kind === 'wallet') {
    doc.rect(x, y + 7, 24, 15).stroke();
    doc.rect(x + 15, y + 11, 9, 8).stroke();
  } else if (kind === 'heart') {
    doc.moveTo(x + 10, y + 20)
      .bezierCurveTo(x + 2, y + 14, x + 3, y + 6, x + 10, y + 8)
      .bezierCurveTo(x + 17, y + 6, x + 18, y + 14, x + 10, y + 20)
      .stroke();
  } else if (kind === 'globe') {
    doc.circle(x + 10, y + 10, 8).stroke();
    doc.moveTo(x + 2, y + 10).lineTo(x + 18, y + 10).stroke();
    doc.moveTo(x + 10, y + 2).lineTo(x + 10, y + 18).stroke();
  } else if (kind === 'whatsapp') {
    doc.circle(x + 10, y + 10, 8).stroke();
    doc.moveTo(x + 6, y + 18).lineTo(x + 7, y + 14).stroke();
    doc.moveTo(x + 8, y + 7).bezierCurveTo(x + 7, y + 10, x + 9, y + 13, x + 13, y + 14).stroke();
  } else if (kind === 'insta' || kind === 'facebook' || kind === 'tiktok') {
    doc.rect(x, y, 20, 20).lineWidth(1.3).stroke(color);
    const label = kind === 'insta' ? 'IG' : kind === 'facebook' ? 'f' : 't';
    drawText(doc, label, x + (kind === 'facebook' ? 7 : 4), y + (kind === 'facebook' ? 3 : 4), {
      size: kind === 'facebook' ? 11 : 8.5,
      bold: true,
      color,
      width: 12,
    });
  }

  doc.restore();
}

function drawSectionHeader(doc, label, x, y, w) {
  doc.save().rect(x, y, w, 28).fill(COLORS.navy).restore();
  drawText(doc, label, x + 14, y + 8, {
    size: 12,
    bold: true,
    color: COLORS.white,
    width: w - 28,
  });
}

function drawFieldRow(doc, config) {
  const {
    icon,
    label,
    value,
    x,
    y,
    width,
    valueX = x + 122,
    split = x + 86,
    lineY,
    multiline = false,
  } = config;

  drawSimpleIcon(doc, icon, x + 10, y + 5, COLORS.aqua);
  drawText(doc, label, x + 42, y + 10, { size: 9.5, color: COLORS.text, width: split - x - 44 });
  drawText(doc, value, valueX, y + 9, {
    size: 9.8,
    color: COLORS.text,
    width: width - (valueX - x) - 14,
    lineGap: multiline ? 2 : 0,
    height: multiline ? 30 : undefined,
  });
  if (lineY != null) {
    drawHLine(doc, x + 10, lineY, x + width - 10);
  }
}

function drawHeader(doc, order) {
  const left = PAGE.margin;
  const top = 26;
  const { date, time } = formatDateParts(order.createdAt);

  if (fs.existsSync(LOGO_PATH)) {
    doc.image(LOGO_PATH, left, top + 2, { fit: [300, 112], align: 'left', valign: 'top' });
  } else {
    drawText(doc, 'ESADAR', left, top + 30, { size: 36, bold: true, color: COLORS.orange });
  }

  drawText(doc, 'COMPROBANTE DE COMPRA', 355, top + 28, {
    size: 23,
    bold: true,
    color: COLORS.navy,
    width: 335,
    align: 'right',
  });

  drawHLine(doc, 375, top + 79, 617, COLORS.aqua, 1.8);
  drawHLine(doc, 617, top + 79, 686, COLORS.orange, 1.8);

  drawText(doc, 'Gracias por elegir ESADAR. Tu compra fue realizada con éxito.', 355, top + 94, {
    size: 10,
    color: COLORS.text,
    width: 335,
    align: 'right',
  });

  const stripY = 155;
  drawRect(doc, left, stripY, 660, 62, { stroke: COLORS.border });
  drawVLine(doc, 258, stripY + 10, stripY + 52);
  drawVLine(doc, 500, stripY + 10, stripY + 52);

  drawSimpleIcon(doc, 'order', left + 22, stripY + 15, COLORS.navy);
  drawText(doc, 'Nº DE PEDIDO', left + 70, stripY + 17, { size: 10, bold: true, color: COLORS.navy });
  drawText(doc, clean(order.orderNumber), left + 70, stripY + 36, { size: 15, bold: true, color: COLORS.navy });

  drawSimpleIcon(doc, 'date', 278, stripY + 15, COLORS.navy);
  drawText(doc, 'FECHA', 324, stripY + 17, { size: 10, bold: true, color: COLORS.navy });
  drawText(doc, `${date}  ·  ${time}`, 324, stripY + 36, { size: 11, color: COLORS.text, width: 160 });

  drawSimpleIcon(doc, 'cart', 522, stripY + 15, COLORS.navy);
  drawText(doc, 'CANAL', 575, stripY + 17, { size: 10, bold: true, color: COLORS.navy });
  drawText(doc, 'Tienda Online', 575, stripY + 36, { size: 11, color: COLORS.text, width: 95 });
}

function drawInfoCards(doc, order, y) {
  const left = PAGE.margin;
  const gap = 20;
  const boxW = 320;
  const boxH = 165;
  const customer = order.customer || {};
  const address = clean(customer.address, 'Sin dirección cargada');
  const shippingMethod = clean(order.shippingMethodDescription, 'A coordinar');
  const paymentLabel = PAYMENT_METHOD_LABELS[order.paymentMethod] || clean(order.paymentMethod, 'Sin datos');
  const paymentStatus = PAYMENT_STATUS_LABELS[order.paymentStatus] || clean(order.paymentStatus, 'Pendiente');

  drawRect(doc, left, y, boxW, boxH);
  drawSectionHeader(doc, 'DATOS DEL CLIENTE', left, y, boxW);
  drawFieldRow(doc, {
    icon: 'person',
    label: 'Nombre',
    value: fullName(customer),
    x: left,
    y: y + 40,
    width: boxW,
    lineY: y + 76,
  });
  drawFieldRow(doc, {
    icon: 'mail',
    label: 'Email',
    value: clean(customer.email),
    x: left,
    y: y + 77,
    width: boxW,
    lineY: y + 113,
  });
  drawFieldRow(doc, {
    icon: 'phone',
    label: 'Teléfono',
    value: clean(customer.phone),
    x: left,
    y: y + 114,
    width: boxW,
  });

  const right = left + boxW + gap;
  drawRect(doc, right, y, boxW, boxH);
  drawSectionHeader(doc, 'DATOS DE ENVÍO', right, y, boxW);
  drawFieldRow(doc, {
    icon: 'person',
    label: 'Nombre',
    value: fullName(customer),
    x: right,
    y: y + 40,
    width: boxW,
    lineY: y + 76,
  });
  drawFieldRow(doc, {
    icon: 'pin',
    label: 'Dirección',
    value: address,
    x: right,
    y: y + 77,
    width: boxW,
    multiline: true,
    lineY: y + 113,
  });
  drawFieldRow(doc, {
    icon: 'home',
    label: 'Método de envío',
    value: shippingMethod,
    x: right,
    y: y + 114,
    width: boxW,
    lineY: y + 149,
  });
  drawFieldRow(doc, {
    icon: 'clock',
    label: 'Plazo estimado',
    value: 'A coordinar',
    x: right,
    y: y + 142,
    width: boxW,
  });

  const payY = y + boxH + 18;
  drawRect(doc, left, payY, 660, 46);
  drawSimpleIcon(doc, 'card', left + 15, payY + 8, COLORS.aqua);
  drawText(doc, 'MÉTODO DE PAGO', left + 58, payY + 15, { size: 11, bold: true, color: COLORS.navy, width: 130 });
  drawText(doc, paymentLabel, left + 190, payY + 15, { size: 10, color: COLORS.text, width: 250 });

  drawSimpleIcon(doc, 'shield', left + 518, payY + 9, COLORS.aqua);
  drawText(doc, paymentStatus, left + 550, payY + 15, { size: 10, color: COLORS.text, width: 98, align: 'right' });

  return payY + 70;
}

function drawItemsTableHeader(doc, y) {
  const x = PAGE.margin;
  doc.save().rect(x, y, 660, 30).fill(COLORS.navy).restore();

  const headers = [
    ['PRENDA', x + 18, 205, 'left'],
    ['MARCA', x + 235, 92, 'left'],
    ['TALLE', x + 334, 52, 'left'],
    ['CANTIDAD', x + 393, 70, 'left'],
    ['PRECIO UNITARIO', x + 470, 100, 'left'],
    ['SUBTOTAL', x + 579, 68, 'right'],
  ];

  headers.forEach(([label, hx, width, align]) => {
    drawText(doc, label, hx, y + 10, {
      size: 8.6,
      bold: true,
      color: COLORS.white,
      width,
      align,
    });
  });
}

function rowHeightForItem(item) {
  const title = clean(item.articleTitle, 'Prenda');
  return title.length > 28 ? 62 : 54;
}

function drawItemRow(doc, item, y) {
  const x = PAGE.margin;
  const rowH = rowHeightForItem(item);
  drawRect(doc, x, y, 660, rowH, { stroke: COLORS.border, lineWidth: 0.6 });

  const title = clean(item.articleTitle, 'Prenda');
  const titleY = y + 10;
  drawText(doc, title, x + 18, titleY, {
    size: 10.5,
    bold: true,
    width: 185,
    height: 24,
    lineGap: 1,
  });

  const meta = [];
  if (item.articleId != null) meta.push(`SKU/ID: ${item.articleId}`);
  if (item.articleSlug) meta.push(item.articleSlug);
  if (item.categoryName) meta.push(item.categoryName);
  drawText(doc, meta.join(' · '), x + 18, y + rowH - 16, {
    size: 8.3,
    color: COLORS.muted,
    width: 190,
  });

  drawText(doc, clean(item.brandName, '-'), x + 235, y + rowH / 2 - 6, { size: 10, width: 85 });
  drawText(doc, clean(item.size, '-'), x + 336, y + rowH / 2 - 6, { size: 10, width: 42 });
  drawText(doc, clean(item.quantity, '0'), x + 405, y + rowH / 2 - 6, { size: 10, width: 40, align: 'center' });
  drawText(doc, formatCurrency(item.finalUnitPrice), x + 465, y + rowH / 2 - 6, { size: 9.7, width: 92, align: 'right' });
  drawText(doc, formatCurrency(item.lineTotal), x + 575, y + rowH / 2 - 6, { size: 10.5, bold: true, color: COLORS.orange, width: 72, align: 'right' });

  return y + rowH;
}

function addContinuationPage(doc, order) {
  doc.addPage({ size: [PAGE.width, PAGE.height], margin: 0 });
  drawText(doc, 'COMPROBANTE DE COMPRA', PAGE.margin, 28, { size: 16, bold: true, color: COLORS.navy, width: 330 });
  drawText(doc, `Orden ${clean(order.orderNumber)}`, PAGE.margin + 375, 31, { size: 10, color: COLORS.muted, width: 285, align: 'right' });
  drawHLine(doc, PAGE.margin, 58, PAGE.width - PAGE.margin, COLORS.aqua, 1.2);
  drawItemsTableHeader(doc, 78);
  return 108;
}

function drawItems(doc, order, y) {
  drawItemsTableHeader(doc, y);
  y += 30;

  for (const item of order.items || []) {
    const rowH = rowHeightForItem(item);
    if (y + rowH > PAGE.height - 190) {
      y = addContinuationPage(doc, order);
    }
    y = drawItemRow(doc, item, y);
  }

  return y + 14;
}

function drawFooterAndTotals(doc, order, y) {
  if (y + 135 > PAGE.height - 60) {
    doc.addPage({ size: [PAGE.width, PAGE.height], margin: 0 });
    y = 60;
  }

  const left = PAGE.margin;
  const thanksY = y + 26;
  drawRect(doc, left, thanksY, 220, 70);
  drawSimpleIcon(doc, 'heart', left + 18, thanksY + 22, COLORS.aqua);
  drawText(doc, '¡Gracias por tu compra!', left + 58, thanksY + 16, {
    size: 10,
    bold: true,
    color: COLORS.navy,
    width: 145,
  });
  drawText(doc, 'Si tenés alguna consulta, estamos\npara ayudarte.', left + 58, thanksY + 34, {
    size: 8.7,
    color: COLORS.text,
    width: 145,
    lineGap: 2,
  });

  const sx = left + 280;
  const sw = 380;
  drawRect(doc, sx, y, sw, 108);
  drawSimpleIcon(doc, 'tag', sx + 18, y + 9, COLORS.aqua);
  drawText(doc, 'DESCUENTOS', sx + 54, y + 14, { size: 10, bold: true, color: COLORS.navy });
  drawText(doc, `- ${formatCurrency(order.discountTotal)}`, sx + 220, y + 14, { size: 10, bold: true, color: COLORS.orange, width: 140, align: 'right' });
  drawHLine(doc, sx, y + 36, sx + sw);

  drawSimpleIcon(doc, 'truck', sx + 18, y + 44, COLORS.aqua);
  drawText(doc, 'ENVÍO', sx + 54, y + 50, { size: 10, bold: true, color: COLORS.navy });
  drawText(doc, formatCurrency(order.shippingCost), sx + 220, y + 50, { size: 10, color: COLORS.text, width: 140, align: 'right' });
  drawHLine(doc, sx, y + 72, sx + sw);

  doc.save().rect(sx, y + 72, sw, 36).fill(COLORS.orange).restore();
  drawSimpleIcon(doc, 'wallet', sx + 18, y + 78, COLORS.white);
  drawText(doc, 'TOTAL', sx + 54, y + 81, { size: 16, bold: true, color: COLORS.white });
  drawText(doc, formatCurrency(order.total), sx + 210, y + 81, { size: 16, bold: true, color: COLORS.white, width: 145, align: 'right' });

  const footerY = PAGE.height - 62;
  drawHLine(doc, left, footerY, PAGE.width - left, COLORS.aqua, 1.7);
  doc.save().lineWidth(1.8).strokeColor(COLORS.orange);
  doc.moveTo(PAGE.width / 2 - 22, footerY + 8).lineTo(PAGE.width / 2 - 6, footerY + 6).lineTo(PAGE.width / 2 + 7, footerY + 2).stroke();
  doc.restore();

  const website = websiteLabel(env.publicSiteUrl);
  const email = clean(env.mail.replyTo || env.mail.fromEmail || 'hola@esadar.com.ar');
  const storePhone = clean(env.storePhone || env.whatsappNumber || '', '');

  drawSimpleIcon(doc, 'globe', left + 6, footerY + 20, COLORS.navy);
  drawText(doc, website, left + 24, footerY + 22, { size: 8.8, color: COLORS.text, width: 120 });
  drawText(doc, '|', left + 155, footerY + 21, { size: 12, color: COLORS.border });

  drawSimpleIcon(doc, 'mail', left + 178, footerY + 22, COLORS.navy);
  drawText(doc, email, left + 200, footerY + 22, { size: 8.8, color: COLORS.text, width: 150 });
  drawText(doc, '|', left + 350, footerY + 21, { size: 12, color: COLORS.border });

  drawSimpleIcon(doc, 'whatsapp', left + 372, footerY + 20, COLORS.navy);
  drawText(doc, storePhone || clean(order.customer?.phone, ''), left + 395, footerY + 22, { size: 8.8, color: COLORS.text, width: 115 });

  drawSimpleIcon(doc, 'insta', left + 545, footerY + 18, COLORS.navy);
  drawSimpleIcon(doc, 'facebook', left + 576, footerY + 18, COLORS.navy);
  drawSimpleIcon(doc, 'tiktok', left + 607, footerY + 18, COLORS.navy);
}

function normalizeOrder(order) {
  return {
    orderNumber: clean(order?.orderNumber),
    createdAt: order?.createdAt,
    paymentMethod: order?.paymentMethod,
    paymentStatus: order?.paymentStatus,
    shippingMethodDescription: order?.shippingMethodDescription,
    shippingCost: asNumber(order?.shippingCost),
    discountTotal: asNumber(order?.discountTotal),
    total: asNumber(order?.total),
    customer: {
      firstName: order?.customer?.firstName,
      lastName: order?.customer?.lastName,
      email: order?.customer?.email,
      phone: order?.customer?.phone,
      address: order?.customer?.address,
    },
    items: (order?.items || []).map((item) => ({
      articleId: item?.articleId,
      articleTitle: item?.articleTitle,
      articleSlug: item?.articleSlug,
      categoryName: item?.categoryName,
      brandName: item?.brandName,
      size: item?.size,
      quantity: item?.quantity,
      finalUnitPrice: asNumber(item?.finalUnitPrice),
      lineTotal: asNumber(item?.lineTotal),
    })),
  };
}

export async function generateOrderReceiptPdf(orderInput) {
  const order = normalizeOrder(orderInput);

  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({
      size: [PAGE.width, PAGE.height],
      margin: 0,
      autoFirstPage: false,
      bufferPages: true,
      info: {
        Title: `Boleta ${order.orderNumber}`,
        Author: 'ESADAR',
      },
    });

    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc.addPage({ size: [PAGE.width, PAGE.height], margin: 0 });
    drawHeader(doc, order);
    let y = drawInfoCards(doc, order, 248);
    y = drawItems(doc, order, y);
    drawFooterAndTotals(doc, order, y);

    doc.end();
  });
}
