import fs from 'node:fs';
import path from 'node:path';
import PDFDocument from 'pdfkit';
import { env } from '../../../config/env.js';

const PAGE = { width: 720, height: 960, margin: 30 };
const COLORS = {
  navy: '#08265a',
  navy2: '#0d2f6f',
  aqua: '#20b8c7',
  aquaSoft: '#e9fbfd',
  orange: '#ff5a00',
  border: '#9bb2d1',
  text: '#0d244f',
  muted: '#607094',
  light: '#f7fbff',
  white: '#ffffff',
};

const LOGO_PATH = path.resolve(new URL('../../../assets/esadar-logo.png', import.meta.url).pathname);

const PAYMENT_METHOD_LABELS = {
  BANK_TRANSFER: 'Transferencia',
  MERCADO_PAGO: 'Mercado Pago',
};

const PAYMENT_STATUS_LABELS = {
  PENDING: 'Pendiente',
  APPROVED: 'Pago aprobado',
  REJECTED: 'Pago rechazado',
  FAILED: 'Pago fallido',
  REFUNDED: 'Pago reintegrado',
  PAID: 'Pago aprobado',
};

function asNumber(value) {
  const parsed = Number(value || 0);
  return Number.isFinite(parsed) ? parsed : 0;
}

function clean(value, fallback = '-') {
  if (value == null) return fallback;
  const text = String(value).trim();
  return text || fallback;
}

function fullName(customer = {}) {
  return [customer.firstName, customer.lastName].map((part) => clean(part, '')).filter(Boolean).join(' ') || '-';
}

function formatCurrency(value) {
  return new Intl.NumberFormat('es-UY', {
    style: 'currency',
    currency: 'UYU',
    maximumFractionDigits: 0,
  }).format(asNumber(value));
}

function pad(value) {
  return String(value).padStart(2, '0');
}

function formatDate(value) {
  if (!value) return '-';
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return '-';
  return `${pad(date.getDate())}/${pad(date.getMonth() + 1)}/${date.getFullYear()} - ${pad(date.getHours())}:${pad(date.getMinutes())} hs`;
}

function resolveImagePath(imagePath) {
  if (!imagePath || /^https?:|^data:|^blob:/i.test(String(imagePath))) return null;
  const normalized = String(imagePath).trim().replace(/\\/g, '/').replace(/^\/+/, '');
  const relativeToUploads = normalized.replace(/^uploads\//i, '');
  const candidates = [
    path.resolve(process.cwd(), normalized),
    path.resolve(env.uploadDir, relativeToUploads),
    path.resolve(env.bundledUploadDir, relativeToUploads),
    path.resolve(process.cwd(), 'public', normalized),
  ];
  return candidates.find((candidate) => fs.existsSync(candidate)) || null;
}

function drawRect(doc, x, y, w, h, options = {}) {
  doc.save();
  if (options.fill) doc.rect(x, y, w, h).fill(options.fill);
  doc.rect(x, y, w, h).lineWidth(options.lineWidth || 0.8).stroke(options.stroke || COLORS.border);
  doc.restore();
}

function text(doc, value, x, y, options = {}) {
  doc
    .font(options.bold ? 'Helvetica-Bold' : 'Helvetica')
    .fontSize(options.size || 10)
    .fillColor(options.color || COLORS.text)
    .text(clean(value, options.fallback || ''), x, y, {
      width: options.width,
      align: options.align || 'left',
      lineGap: options.lineGap || 0,
      continued: options.continued || false,
    });
}

function sectionHeader(doc, label, x, y, w) {
  doc.save().rect(x, y, w, 28).fill(COLORS.navy).restore();
  text(doc, label, x + 14, y + 8, { size: 12, bold: true, color: COLORS.white, width: w - 28 });
}

function drawSimpleIcon(doc, kind, x, y, color = COLORS.aqua) {
  doc.save().lineWidth(1.8).strokeColor(color).fillColor(color);
  if (kind === 'order') {
    doc.rect(x, y + 4, 22, 24).stroke();
    doc.moveTo(x + 6, y + 4).lineTo(x + 6, y).lineTo(x + 16, y).lineTo(x + 16, y + 4).stroke();
    doc.circle(x + 11, y + 16, 4).stroke();
  } else if (kind === 'date') {
    doc.rect(x, y + 5, 25, 23).stroke();
    doc.moveTo(x, y + 12).lineTo(x + 25, y + 12).stroke();
    doc.moveTo(x + 7, y).lineTo(x + 7, y + 8).stroke();
    doc.moveTo(x + 18, y).lineTo(x + 18, y + 8).stroke();
  } else if (kind === 'cart') {
    doc.moveTo(x, y + 6).lineTo(x + 4, y + 6).lineTo(x + 8, y + 21).lineTo(x + 24, y + 21).stroke();
    doc.moveTo(x + 7, y + 11).lineTo(x + 24, y + 11).lineTo(x + 21, y + 18).stroke();
    doc.circle(x + 10, y + 27, 2).stroke();
    doc.circle(x + 22, y + 27, 2).stroke();
  } else if (kind === 'card') {
    doc.rect(x, y + 5, 28, 20).stroke();
    doc.moveTo(x, y + 12).lineTo(x + 28, y + 12).stroke();
  } else if (kind === 'tag') {
    doc.polygon([x + 3, y + 3], [x + 18, y + 3], [x + 27, y + 12], [x + 13, y + 26], [x + 3, y + 16]).stroke();
    doc.circle(x + 13, y + 10, 2).stroke();
  } else if (kind === 'truck') {
    doc.rect(x, y + 9, 18, 12).stroke();
    doc.rect(x + 18, y + 13, 10, 8).stroke();
    doc.circle(x + 7, y + 24, 2).stroke();
    doc.circle(x + 22, y + 24, 2).stroke();
  } else if (kind === 'wallet') {
    doc.rect(x, y + 7, 28, 18).stroke();
    doc.rect(x + 17, y + 13, 11, 8).stroke();
  } else if (kind === 'heart') {
    text(doc, '♡', x, y, { size: 24, bold: true, color });
  } else {
    text(doc, '□', x, y, { size: 18, color });
  }
  doc.restore();
}

function drawHeader(doc, order) {
  const left = PAGE.margin;
  const top = 30;
  if (fs.existsSync(LOGO_PATH)) {
    doc.image(LOGO_PATH, left, top + 6, { fit: [295, 112] });
  } else {
    text(doc, 'ESADAR', left, top + 30, { size: 36, bold: true, color: COLORS.orange });
  }

  text(doc, 'COMPROBANTE DE COMPRA', 365, top + 30, { size: 24, bold: true, color: COLORS.navy, width: 320, align: 'right' });
  doc.save().lineWidth(2).strokeColor(COLORS.aqua).moveTo(374, top + 78).lineTo(616, top + 78).stroke();
  doc.strokeColor(COLORS.orange).moveTo(616, top + 78).lineTo(686, top + 78).stroke().restore();
  text(doc, 'Gracias por elegir ESADAR. Tu compra fue realizada con exito.', 365, top + 94, { size: 10, color: COLORS.text, width: 320, align: 'right' });

  const stripY = 155;
  drawRect(doc, left, stripY, 660, 62, { stroke: COLORS.navy });
  doc.save().strokeColor(COLORS.navy).lineWidth(0.8);
  doc.moveTo(258, stripY + 10).lineTo(258, stripY + 52).stroke();
  doc.moveTo(500, stripY + 10).lineTo(500, stripY + 52).stroke();
  doc.restore();

  drawSimpleIcon(doc, 'order', left + 20, stripY + 16, COLORS.navy);
  text(doc, 'Nº DE PEDIDO', left + 68, stripY + 17, { size: 10, bold: true, color: COLORS.navy });
  text(doc, order.orderNumber, left + 68, stripY + 36, { size: 15, bold: true, color: COLORS.navy });

  drawSimpleIcon(doc, 'date', 278, stripY + 15, COLORS.navy);
  text(doc, 'FECHA', 324, stripY + 17, { size: 10, bold: true, color: COLORS.navy });
  text(doc, formatDate(order.createdAt), 324, stripY + 36, { size: 11, color: COLORS.text, width: 160 });

  drawSimpleIcon(doc, 'cart', 522, stripY + 15, COLORS.navy);
  text(doc, 'CANAL', 575, stripY + 17, { size: 10, bold: true, color: COLORS.navy });
  text(doc, 'Tienda Online', 575, stripY + 36, { size: 11, color: COLORS.text });
}

function drawInfoCards(doc, order, y) {
  const left = PAGE.margin;
  const gap = 20;
  const boxW = (660 - gap) / 2;
  const boxH = 155;
  const customer = order.customer || {};
  const paymentLabel = PAYMENT_METHOD_LABELS[order.paymentMethod] || clean(order.paymentMethod);
  const paymentStatus = PAYMENT_STATUS_LABELS[order.paymentStatus] || clean(order.paymentStatus);

  drawRect(doc, left, y, boxW, boxH);
  sectionHeader(doc, 'DATOS DEL CLIENTE', left, y, boxW);
  text(doc, 'Nombre', left + 48, y + 55, { size: 10, bold: true });
  text(doc, fullName(customer), left + 130, y + 55, { size: 10, width: boxW - 145 });
  text(doc, 'Email', left + 48, y + 88, { size: 10, bold: true });
  text(doc, clean(customer.email), left + 130, y + 88, { size: 10, width: boxW - 145 });
  text(doc, 'Telefono', left + 48, y + 121, { size: 10, bold: true });
  text(doc, clean(customer.phone), left + 130, y + 121, { size: 10, width: boxW - 145 });
  ['Nombre', 'Email', 'Telefono'].forEach((_, i) => {
    doc.save().strokeColor(COLORS.border).moveTo(left + 10, y + 76 + i * 33).lineTo(left + boxW - 10, y + 76 + i * 33).stroke().restore();
  });

  const right = left + boxW + gap;
  drawRect(doc, right, y, boxW, boxH);
  sectionHeader(doc, 'DATOS DE ENVIO', right, y, boxW);
  text(doc, 'Nombre', right + 48, y + 55, { size: 10, bold: true });
  text(doc, fullName(customer), right + 130, y + 55, { size: 10, width: boxW - 145 });
  text(doc, 'Direccion', right + 48, y + 85, { size: 10, bold: true });
  text(doc, clean(customer.address, 'Sin direccion cargada'), right + 130, y + 85, { size: 10, width: boxW - 145, lineGap: 1 });
  text(doc, 'Metodo de envio', right + 48, y + 123, { size: 10, bold: true });
  text(doc, clean(order.shippingMethodDescription, 'Sin datos'), right + 142, y + 123, { size: 10, width: boxW - 155 });
  [76, 110].forEach((yy) => doc.save().strokeColor(COLORS.border).moveTo(right + 10, y + yy).lineTo(right + boxW - 10, y + yy).stroke().restore());

  const payY = y + boxH + 18;
  drawRect(doc, left, payY, 660, 46);
  drawSimpleIcon(doc, 'card', left + 16, payY + 9, COLORS.aqua);
  text(doc, 'METODO DE PAGO', left + 64, payY + 16, { size: 11, bold: true, color: COLORS.navy });
  text(doc, paymentLabel, left + 205, payY + 16, { size: 10, color: COLORS.text, width: 260 });
  text(doc, paymentStatus, left + 525, payY + 16, { size: 10, bold: true, color: COLORS.text, width: 120, align: 'right' });

  return payY + 66;
}

function drawTableHeader(doc, y) {
  const x = PAGE.margin;
  doc.save().rect(x, y, 660, 30).fill(COLORS.navy).restore();
  const headers = [
    ['IMAGEN', x + 12, 62],
    ['PRENDA', x + 108, 145],
    ['MARCA', x + 270, 75],
    ['TALLE', x + 356, 55],
    ['CANT.', x + 420, 55],
    ['PRECIO UNIT.', x + 488, 92],
    ['SUBTOTAL', x + 585, 65],
  ];
  headers.forEach(([label, colX, width]) => text(doc, label, colX, y + 10, { size: 8.5, bold: true, color: COLORS.white, width, align: label === 'SUBTOTAL' ? 'right' : 'left' }));
}

function drawTableRow(doc, item, y) {
  const x = PAGE.margin;
  const rowH = 70;
  drawRect(doc, x, y, 660, rowH, { stroke: COLORS.border, lineWidth: 0.5 });
  const img = resolveImagePath(item.image);
  if (img) {
    try {
      doc.image(img, x + 12, y + 8, { fit: [54, 54], align: 'center', valign: 'center' });
    } catch {
      drawRect(doc, x + 12, y + 8, 54, 54, { stroke: '#d0d7e2', fill: COLORS.light });
      text(doc, 'IMG', x + 24, y + 29, { size: 8, color: COLORS.muted });
    }
  } else {
    drawRect(doc, x + 12, y + 8, 54, 54, { stroke: '#d0d7e2', fill: COLORS.light });
    text(doc, 'IMG', x + 24, y + 29, { size: 8, color: COLORS.muted });
  }

  text(doc, clean(item.articleTitle, 'Prenda'), x + 100, y + 14, { size: 10, bold: true, width: 145 });
  text(doc, `#${clean(item.articleId, 's/d')}`, x + 100, y + 42, { size: 8.5, color: COLORS.muted, width: 145 });
  text(doc, clean(item.brandName, 'Sin marca'), x + 270, y + 27, { size: 10, width: 72 });
  text(doc, clean(item.size, '-'), x + 360, y + 27, { size: 10, width: 40 });
  text(doc, clean(item.quantity, '0'), x + 430, y + 27, { size: 10, width: 35, align: 'center' });
  text(doc, formatCurrency(item.finalUnitPrice), x + 488, y + 27, { size: 9.5, width: 86, align: 'right' });
  text(doc, formatCurrency(item.lineTotal), x + 585, y + 27, { size: 10, bold: true, color: COLORS.orange, width: 65, align: 'right' });
  return y + rowH;
}

function addContinuationPage(doc, order) {
  doc.addPage({ size: [PAGE.width, PAGE.height], margin: 0 });
  text(doc, 'COMPROBANTE DE COMPRA', PAGE.margin, 28, { size: 16, bold: true, color: COLORS.navy, width: 330 });
  text(doc, `Orden ${order.orderNumber}`, PAGE.margin + 390, 32, { size: 10, color: COLORS.muted, width: 270, align: 'right' });
  doc.save().strokeColor(COLORS.aqua).moveTo(PAGE.margin, 58).lineTo(PAGE.width - PAGE.margin, 58).stroke().restore();
  drawTableHeader(doc, 78);
  return 108;
}

function drawItems(doc, order, y) {
  drawTableHeader(doc, y);
  y += 30;
  for (const item of order.items || []) {
    if (y + 70 > PAGE.height - 190) {
      y = addContinuationPage(doc, order);
    }
    y = drawTableRow(doc, item, y);
  }
  return y + 14;
}

function drawFooterAndTotals(doc, order, y) {
  if (y + 130 > PAGE.height - 58) {
    doc.addPage({ size: [PAGE.width, PAGE.height], margin: 0 });
    y = 48;
  }

  const left = PAGE.margin;
  drawRect(doc, left, y + 25, 220, 70);
  drawSimpleIcon(doc, 'heart', left + 16, y + 43, COLORS.aqua);
  text(doc, '¡Gracias por tu compra!', left + 58, y + 42, { size: 10, bold: true, color: COLORS.navy, width: 145 });
  text(doc, 'Si tienes alguna consulta, estamos para ayudarte.', left + 58, y + 60, { size: 8.5, color: COLORS.text, width: 145 });

  const sx = left + 292;
  const sw = 368;
  drawRect(doc, sx, y, sw, 95);
  drawSimpleIcon(doc, 'tag', sx + 18, y + 8, COLORS.aqua);
  text(doc, 'DESCUENTOS', sx + 58, y + 14, { size: 10, bold: true, color: COLORS.navy });
  text(doc, `- ${formatCurrency(order.discountTotal)}`, sx + 210, y + 14, { size: 10, bold: true, color: COLORS.orange, width: 140, align: 'right' });
  doc.save().strokeColor(COLORS.border).moveTo(sx, y + 36).lineTo(sx + sw, y + 36).stroke().restore();
  drawSimpleIcon(doc, 'truck', sx + 18, y + 42, COLORS.aqua);
  text(doc, 'ENVIO', sx + 58, y + 51, { size: 10, bold: true, color: COLORS.navy });
  text(doc, formatCurrency(order.shippingCost), sx + 210, y + 51, { size: 10, bold: true, color: COLORS.text, width: 140, align: 'right' });
  doc.save().rect(sx, y + 70, sw, 42).fill(COLORS.orange).restore();
  drawSimpleIcon(doc, 'wallet', sx + 18, y + 78, COLORS.white);
  text(doc, 'TOTAL', sx + 58, y + 82, { size: 16, bold: true, color: COLORS.white });
  text(doc, formatCurrency(order.total), sx + 188, y + 82, { size: 16, bold: true, color: COLORS.white, width: 160, align: 'right' });

  const footerY = PAGE.height - 62;
  doc.save().strokeColor(COLORS.aqua).lineWidth(1.5).moveTo(left, footerY).lineTo(PAGE.width - left, footerY).stroke();
  doc.strokeColor(COLORS.orange).moveTo(PAGE.width / 2 - 25, footerY + 8).lineTo(PAGE.width / 2 + 25, footerY + 2).stroke().restore();
  text(doc, clean(env.publicSiteUrl, 'www.esadar.com'), left, footerY + 22, { size: 9, color: COLORS.text, width: 210 });
  text(doc, clean(env.mail.replyTo || env.mail.fromEmail || 'hola@esadar.com'), left + 240, footerY + 22, { size: 9, color: COLORS.text, width: 210 });
  text(doc, 'ESADAR', left + 505, footerY + 22, { size: 9, bold: true, color: COLORS.navy, width: 140, align: 'right' });
}

export async function generateOrderReceiptPdf(order) {
  return new Promise((resolve, reject) => {
    const doc = new PDFDocument({ size: [PAGE.width, PAGE.height], margin: 0, autoFirstPage: false, bufferPages: true, info: { Title: `Boleta ${order.orderNumber}`, Author: 'ESADAR' } });
    const chunks = [];
    doc.on('data', (chunk) => chunks.push(chunk));
    doc.on('end', () => resolve(Buffer.concat(chunks)));
    doc.on('error', reject);

    doc.addPage({ size: [PAGE.width, PAGE.height], margin: 0 });
    drawHeader(doc, order);
    let y = drawInfoCards(doc, order, 248);
    y = drawItems(doc, order, y);
    drawFooterAndTotals(doc, order, y);
    doc.end();
  });
}
