import { createContext, useContext, useEffect, useMemo, useState } from 'react';
import { storage } from '../lib/storage.js';
import { THEME_IDS, THEME_MAP, THEME_OPTIONS, getThemeGroups } from '../constants/themes.js';

const ThemeContext = createContext(null);
const STORAGE_KEY = 'miami-closet-theme';

function normalizeTheme(rawTheme) {
  if (rawTheme === 'alt') return 'marine';
  if (THEME_IDS.includes(rawTheme)) return rawTheme;
  return 'default';
}

function applyThemeVariables(themeId) {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  const theme = THEME_MAP[themeId] || THEME_MAP.default;

  Object.entries(theme.vars || {}).forEach(([key, value]) => {
    root.style.setProperty(key, value);
  });
}

export function ThemeProvider({ children }) {
  const [theme, setThemeState] = useState(() => normalizeTheme(storage.get(STORAGE_KEY, 'default')));

  function setTheme(nextTheme) {
    setThemeState(normalizeTheme(nextTheme));
  }

  useEffect(() => {
    document.documentElement.dataset.theme = theme;
    applyThemeVariables(theme);
    storage.set(STORAGE_KEY, theme);
  }, [theme]);

  const value = useMemo(
    () => ({
      theme,
      themes: THEME_OPTIONS,
      themeGroups: getThemeGroups(),
      setTheme,
      cycleTheme: () => {
        const currentIndex = THEME_IDS.indexOf(theme);
        const nextIndex = (currentIndex + 1) % THEME_IDS.length;
        setTheme(THEME_IDS[nextIndex]);
      },
      randomTheme: () => {
        const nextIndex = Math.floor(Math.random() * THEME_IDS.length);
        setTheme(THEME_IDS[nextIndex]);
      },
    }),
    [theme],
  );

  return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used inside ThemeProvider');
  return context;
}
