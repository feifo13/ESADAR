import { Link } from 'react-router-dom';
import { formatCurrency, getDiscountedPrice, hasDiscount, cn } from '../lib/format.js';
import { articleOfferPath, articlePath } from '../lib/routes.js';
import { useCart } from '../contexts/CartContext.jsx';
import { useWishlist } from '../contexts/WishlistContext.jsx';
import SmartImage from './SmartImage.jsx';
import WishlistHeartButton from './WishlistHeartButton.jsx';

const SHOW_CARD_BADGES = false;
const SHOW_TEXT_WISHLIST_ACTION = false;
const SHOW_CARD_OFFER_ACTION = false;

export default function ArticleCard({ article, view = 'grid' }) {
  const { addItem } = useCart();
  const { isSaved, toggleItem, pendingIds } = useWishlist();
  const discounted = hasDiscount(article);
  const price = getDiscountedPrice(article);
  const isSoldOut = Number(article.quantityAvailable || 0) <= 0 || article.status === 'SOLD_OUT';
  const categoryName = article.category?.name || article.categoryName || 'Sin categoria';
  const brandName = article.brand?.name || article.brandName || '';
  const sizeLabel = article.sizeText || article.size?.code || article.sizeCode || 'Talle no especificado';
  const conditionLabel = article.conditionLabel || '';
  const colorLabel = article.color || '';
  const materialLabel = article.material || '';
  const isUniquePiece = Number(article.quantityTotal || 0) <= 1;
  const saved = isSaved(article.id);
  const pending = pendingIds.includes(Number(article.id));
  const showOfferRibbon = article.allowOffers && !isSoldOut;
  const detailPath = articlePath(article);
  const offerPath = articleOfferPath(article);
  const imageSources = article.primaryImageDetail || article.primaryImageThumb ? [
    article.primaryImageDetail ? { srcSet: `${article.primaryImageDetail} 900w`, media: '(min-width: 720px)', type: 'image/webp' } : null,
    article.primaryImage ? { srcSet: `${article.primaryImage} 560w`, type: 'image/webp' } : null,
  ].filter(Boolean) : [];

  const optimisticWishlistItem = {
    articleId: article.id,
    slug: article.slug,
    title: article.title,
    salePrice: article.salePrice,
    discountType: article.discountType,
    discountValue: article.discountValue,
    discountedPrice: article.discountedPrice,
    status: article.status,
    conditionLabel: article.conditionLabel,
    color: article.color,
    material: article.material,
    quantityAvailable: article.quantityAvailable,
    brandName: article.brandName,
    sizeLabel,
    image: article.primaryImage || '',
    allowOffers: article.allowOffers,
  };

  return (
    <article className={cn('article-card', view === 'list' && 'article-card-list', isSoldOut && 'article-card--sold-out')}>
      <div className="article-card-media-wrap">
        <Link className="article-card-media" to={detailPath}>
          {isSoldOut ? <span className="article-card-ribbon">Agotado</span> : null}
          {!isSoldOut && showOfferRibbon ? <span className="article-card-ribbon article-card-ribbon--offerable">Acepta ofertas</span> : null}
          <SmartImage
            src={article.primaryImage || article.primaryImageThumb || article.primaryImageDetail}
            alt={article.primaryImageAlt || article.title}
            fallbackLabel={article.title}
            loading="lazy"
            sources={imageSources}
          />
        </Link>

        <WishlistHeartButton
          active={saved}
          pending={pending}
          className="article-card-heart"
          labelActive="Quitar de guardados"
          labelInactive="Guardar articulo"
          onToggle={() => void toggleItem(article, optimisticWishlistItem)}
        />
      </div>

      <div className="article-card-body">
        <div className={SHOW_CARD_BADGES ? 'article-card-tags' : 'article-card-tags article-card-tags--hidden'} aria-hidden={!SHOW_CARD_BADGES}>
          {article.isFeatured ? <span className="pill pill-featured">Destacado</span> : null}
          {article.allowOffers ? <span className="pill pill-offer">Acepta ofertas</span> : null}
          {discounted ? <span className="pill pill-discount">Descuento</span> : null}
          {isUniquePiece ? <span className="pill pill-unique">Pieza unica</span> : null}
          {isSoldOut ? <span className="pill pill-soldout">Agotado</span> : null}
        </div>

        <div className="article-card-copy">
          <p className="eyebrow">{categoryName}{brandName ? ` · ${brandName}` : ''}</p>
          <Link to={detailPath} className="article-card-title">
            {article.title}
          </Link>
          <div className="article-card-details">
            <p className="article-card-meta">Talle: {sizeLabel}</p>
            {conditionLabel ? <p className="article-card-detail-line">Estado: {conditionLabel}</p> : null}
            {colorLabel ? <p className="article-card-detail-line">Color: {colorLabel}</p> : null}
            {materialLabel ? <p className="article-card-detail-line">Material: {materialLabel}</p> : null}
            <p className="article-card-detail-line">{isSoldOut ? 'Sin stock' : `${Number(article.quantityAvailable || 0)} disponibles`}</p>
          </div>
        </div>

        <div className="article-card-pricebox">
          {discounted ? <span className="price-old">{formatCurrency(article.salePrice)}</span> : null}
          <span className="price-current">{formatCurrency(price)}</span>
        </div>

        <div className="article-card-actions">
          <Link to={detailPath} className="button button-secondary button-compact">
            Ver prenda
          </Link>
          {SHOW_TEXT_WISHLIST_ACTION ? (
            <button
              type="button"
              className={saved ? 'button button-secondary button-compact is-active' : 'button button-secondary button-compact'}
              onClick={() => void toggleItem(article, optimisticWishlistItem)}
              disabled={pending}
            >
              {saved ? 'Guardado' : 'Guardar'}
            </button>
          ) : null}
          {!isSoldOut ? (
            <button
              type="button"
              className="button button-primary button-compact"
              onClick={(event) => {
                addItem(article, 1, { sourceRect: event.currentTarget.getBoundingClientRect() });
              }}
            >
              Agregar al carrito
            </button>
          ) : null}
          {SHOW_CARD_OFFER_ACTION && article.allowOffers && !isSoldOut ? (
            <Link to={offerPath} className="button button-secondary button-compact">
              Ofertar
            </Link>
          ) : null}
        </div>
      </div>
    </article>
  );
}
