import { Link, NavLink, useLocation, useNavigate } from "react-router-dom";
import { useEffect, useRef, useState } from "react";
import { useAuth } from "../contexts/AuthContext.jsx";
import { useCart } from "../contexts/CartContext.jsx";
import SurfaceModal from "./SurfaceModal.jsx";
import esadarWordmark from "../assets/esadar-wordmark.png";

function findVisibleTargetRect(...refs) {
  for (const ref of refs) {
    const element = ref.current;
    if (!element) continue;
    const rect = element.getBoundingClientRect();
    if (rect.width > 0 && rect.height > 0) return rect;
  }
  return null;
}

export default function Header({ hideBrand = false }) {
  const navigate = useNavigate();
  const location = useLocation();
  const { user, logout, isAuthenticated } = useAuth();
  const { cartCount, cartFx } = useCart();
  const [cartPulse, setCartPulse] = useState(false);
  const [flyFx, setFlyFx] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const desktopCartButtonRef = useRef(null);
  const mobileCartButtonRef = useRef(null);

  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  useEffect(() => {
    if (!cartFx?.tick) return undefined;

    setCartPulse(true);
    const timeoutId = window.setTimeout(() => setCartPulse(false), 900);

    const sourceRect = cartFx.sourceRect;
    const targetRect = findVisibleTargetRect(mobileCartButtonRef, desktopCartButtonRef);

    if (sourceRect && targetRect) {
      const startX = sourceRect.left + sourceRect.width / 2;
      const startY = sourceRect.top + sourceRect.height / 2;
      const endX = targetRect.left + targetRect.width / 2;
      const endY = targetRect.top + targetRect.height / 2;
      const deltaX = endX - startX;
      const deltaY = endY - startY;
      const curveLift = Math.max(48, Math.min(160, Math.abs(deltaY) * 0.55 + 72));

      setFlyFx({
        id: cartFx.tick,
        style: {
          "--cart-fly-start-x": `${startX}px`,
          "--cart-fly-start-y": `${startY}px`,
          "--cart-fly-dx": `${deltaX}px`,
          "--cart-fly-dy": `${deltaY}px`,
          "--cart-fly-lift": `${curveLift}px`,
        },
      });

      const flyTimer = window.setTimeout(() => setFlyFx(null), 960);
      return () => {
        window.clearTimeout(timeoutId);
        window.clearTimeout(flyTimer);
      };
    }

    return () => window.clearTimeout(timeoutId);
  }, [cartFx?.tick, cartFx?.sourceRect]);

  const isAdmin = user?.roles?.some((role) =>
    ["SUPER_ADMIN", "ADMIN", "OPERATOR"].includes(role),
  );

  function openCart() {
    navigate("/checkout/resumen", { state: { replayIntro: true, replayIntroReason: "cart" } });
  }

  function renderCartButton(buttonRef, extraClassName = "") {
    return (
      <button
        ref={buttonRef}
        type="button"
        className={[
          "ghost-button",
          "cart-button",
          "cart-button--icon-only",
          cartPulse ? "cart-button--pulse" : "",
          extraClassName,
        ].filter(Boolean).join(" ")}
        onClick={openCart}
        aria-label="Carrito"
        title="Carrito"
      >
        <svg
          className="cart-button__icon"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <circle cx="9" cy="20" r="1.6" />
          <circle cx="18" cy="20" r="1.6" />
          <path d="M3 4h2.2l1.9 9.2a1 1 0 0 0 1 .8h8.8a1 1 0 0 0 1-.8L20 7H7.1" />
        </svg>
        <span className={`badge${cartPulse ? " badge--pulse" : ""}`}>{cartCount}</span>
      </button>
    );
  }

  return (
    <>
      <header className="site-header">
        <div className="container header-inner header-inner--compact">
          <Link
            to="/"
            className={`brand-mark ${hideBrand ? "brand-mark--hidden" : ""}`}
            aria-label="ESADAR"
          >
            <img
              src={esadarWordmark}
              alt="ESADAR"
              className="brand-mark__logo"
            />
          </Link>

          <div className="header-actions header-actions--ordered header-actions--desktop">
            {isAuthenticated ? (
              <>
                <span className="user-greeting">Hola, {user?.firstName || ""}</span>
                <NavLink to="/articles" className="ghost-button linklike">
                  CATÁLOGO
                </NavLink>
                <NavLink to="/cuenta/perfil" className="ghost-button linklike">
                  MI CUENTA
                </NavLink>
                <NavLink to="/cuenta/guardados" className="ghost-button linklike">
                  GUARDADOS
                </NavLink>
                {isAdmin ? (
                  <NavLink to="/admin/articles" className="ghost-button linklike">
                    ADMIN
                  </NavLink>
                ) : null}
                {renderCartButton(desktopCartButtonRef)}
                <button type="button" className="ghost-button" onClick={logout}>
                  SALIR
                </button>
              </>
            ) : (
              <>
                <NavLink to="/articles" className="ghost-button linklike">
                  CATÁLOGO
                </NavLink>
                <NavLink to="/cuenta/guardados" className="ghost-button linklike">
                  GUARDADOS
                </NavLink>
                {renderCartButton(desktopCartButtonRef)}
                <NavLink to="/login" className="ghost-button linklike">
                  INGRESAR
                </NavLink>
              </>
            )}
          </div>

          <div className="header-actions-mobile">
            {isAdmin ? (
              <NavLink to="/admin/articles" className="ghost-button linklike header-actions-mobile__admin">
                ADMIN
              </NavLink>
            ) : null}
            {renderCartButton(mobileCartButtonRef, "header-actions-mobile__cart")}
            <button
              type="button"
              className="ghost-button header-actions-mobile__menu"
              aria-label="Abrir menu"
              onClick={() => setMobileMenuOpen(true)}
            >
              <span />
              <span />
              <span />
            </button>
          </div>
        </div>
      </header>

      <SurfaceModal
        open={mobileMenuOpen}
        onClose={() => setMobileMenuOpen(false)}
        title="Menu"
        description="Navegacion principal de ESADAR."
        className="mobile-nav-sheet"
      >
        <nav className="mobile-nav-sheet__links" aria-label="Navegacion principal">
          <NavLink to="/" className="button button-secondary mobile-nav-sheet__link">
            Inicio
          </NavLink>
          <NavLink to="/articles" className="button button-secondary mobile-nav-sheet__link">
            Catálogo
          </NavLink>
          <NavLink to="/cuenta/guardados" className="button button-secondary mobile-nav-sheet__link">
            Guardados
          </NavLink>

          {isAuthenticated ? (
            <>
              <NavLink to="/cuenta/perfil" className="button button-secondary mobile-nav-sheet__link">
                Mi cuenta
              </NavLink>
              <NavLink to="/cuenta/alertas" className="button button-secondary mobile-nav-sheet__link">
                Mis alertas
              </NavLink>
              <NavLink to="/cuenta/ordenes" className="button button-secondary mobile-nav-sheet__link">
                Mis ordenes
              </NavLink>
              {isAdmin ? (
                <NavLink to="/admin/articles" className="button button-secondary mobile-nav-sheet__link">
                  Admin
                </NavLink>
              ) : null}
              <button type="button" className="button button-secondary mobile-nav-sheet__link" onClick={openCart}>
                Carrito ({cartCount})
              </button>
              <button
                type="button"
                className="button button-primary mobile-nav-sheet__link"
                onClick={() => {
                  logout();
                  setMobileMenuOpen(false);
                }}
              >
                Salir
              </button>
            </>
          ) : (
            <>
              <button type="button" className="button button-secondary mobile-nav-sheet__link" onClick={openCart}>
                Carrito ({cartCount})
              </button>
              <NavLink to="/login" className="button button-primary mobile-nav-sheet__link">
                Ingresar
              </NavLink>
              <NavLink to="/register" className="button button-secondary mobile-nav-sheet__link">
                Crear cuenta
              </NavLink>
            </>
          )}
        </nav>
      </SurfaceModal>

      {flyFx ? (
        <span key={flyFx.id} className="cart-fly-token" style={flyFx.style} aria-hidden="true">
          <span className="cart-fly-token__core" />
        </span>
      ) : null}
    </>
  );
}
