import { createContext, useCallback, useContext, useMemo, useState } from 'react';

const MobileMenuContext = createContext({
  catalogFiltersContent: null,
  setCatalogFiltersContent: () => undefined,
  catalogSortContent: null,
  setCatalogSortContent: () => undefined,
  activeCatalogFiltersCount: 0,
  setActiveCatalogFiltersCount: () => undefined,
  clearCatalogFilters: null,
  setClearCatalogFilters: () => undefined,
});

export function MobileMenuProvider({ children }) {
  const [catalogFiltersContent, setCatalogFiltersContent] = useState(null);
  const [catalogSortContent, setCatalogSortContent] = useState(null);
  const [activeCatalogFiltersCount, setActiveCatalogFiltersCount] = useState(0);
  const [clearCatalogFilters, setClearCatalogFiltersState] = useState(null);

  const setClearCatalogFilters = useCallback((handler) => {
    setClearCatalogFiltersState(() => (typeof handler === 'function' ? handler : null));
  }, []);

  const value = useMemo(
    () => ({
      catalogFiltersContent,
      setCatalogFiltersContent,
      catalogSortContent,
      setCatalogSortContent,
      activeCatalogFiltersCount,
      setActiveCatalogFiltersCount,
      clearCatalogFilters,
      setClearCatalogFilters,
    }),
    [catalogFiltersContent, catalogSortContent, activeCatalogFiltersCount, clearCatalogFilters, setClearCatalogFilters],
  );

  return (
    <MobileMenuContext.Provider value={value}>
      {children}
    </MobileMenuContext.Provider>
  );
}

export function useMobileMenu() {
  return useContext(MobileMenuContext);
}
