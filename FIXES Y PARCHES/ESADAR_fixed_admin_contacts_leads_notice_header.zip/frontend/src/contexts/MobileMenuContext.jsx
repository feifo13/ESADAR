import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

const DEFAULT_NOTICE_DURATION_MS = 4200;

const MobileMenuContext = createContext({
  catalogFiltersContent: null,
  catalogFiltersCount: 0,
  clearCatalogFilters: null,
  setCatalogFiltersContent: () => undefined,
  setCatalogFiltersMeta: () => undefined,
  notifyMobileStatus: () => undefined,
});

function getNoticeIcon(type) {
  if (type === 'success') return '✓';
  if (type === 'error') return '!';
  if (type === 'warning') return '!';
  return 'i';
}

export function MobileMenuProvider({ children }) {
  const [catalogFiltersContent, setCatalogFiltersContent] = useState(null);
  const [catalogFiltersMeta, setCatalogFiltersMeta] = useState({
    count: 0,
    onClear: null,
  });
  const [statusNotice, setStatusNotice] = useState(null);
  const noticeTimerRef = useRef(null);

  const clearStatusNotice = useCallback(() => {
    if (noticeTimerRef.current) {
      window.clearTimeout(noticeTimerRef.current);
      noticeTimerRef.current = null;
    }
    setStatusNotice(null);
  }, []);

  const notifyMobileStatus = useCallback((notice = {}) => {
    const message = String(notice.message || '').trim();
    if (!message) return;

    if (noticeTimerRef.current) {
      window.clearTimeout(noticeTimerRef.current);
    }

    const type = notice.type || 'info';
    const duration = Number(notice.durationMs || DEFAULT_NOTICE_DURATION_MS);

    const icon = ['success', 'error', 'warning', 'info'].includes(notice.icon)
      ? getNoticeIcon(type)
      : notice.icon || getNoticeIcon(type);

    setStatusNotice({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type,
      message,
      icon,
    });

    noticeTimerRef.current = window.setTimeout(() => {
      setStatusNotice(null);
      noticeTimerRef.current = null;
    }, duration);
  }, []);

  useEffect(
    () => () => {
      if (noticeTimerRef.current) {
        window.clearTimeout(noticeTimerRef.current);
      }
    },
    [],
  );

  const value = useMemo(
    () => ({
      catalogFiltersContent,
      catalogFiltersCount: Number(catalogFiltersMeta.count || 0),
      clearCatalogFilters: catalogFiltersMeta.onClear,
      setCatalogFiltersContent,
      setCatalogFiltersMeta,
      notifyMobileStatus,
    }),
    [catalogFiltersContent, catalogFiltersMeta, notifyMobileStatus],
  );

  return (
    <MobileMenuContext.Provider value={value}>
      {children}
      {statusNotice ? (
        <div
          key={statusNotice.id}
          className={`mobile-status-band mobile-status-band--${statusNotice.type}`}
          role="status"
          aria-live="polite"
        >
          <span className="mobile-status-band__icon" aria-hidden="true">
            {statusNotice.icon}
          </span>
          <p className="mobile-status-band__message">{statusNotice.message}</p>
          <button
            type="button"
            className="mobile-status-band__close"
            onClick={clearStatusNotice}
            aria-label="Cerrar aviso"
          >
            ×
          </button>
        </div>
      ) : null}
    </MobileMenuContext.Provider>
  );
}

export function useMobileMenu() {
  return useContext(MobileMenuContext);
}
