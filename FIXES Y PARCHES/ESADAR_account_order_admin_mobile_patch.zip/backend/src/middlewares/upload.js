import fs from 'node:fs';
import path from 'node:path';
import multer from 'multer';
import { randomUUID } from 'node:crypto';
import { env } from '../config/env.js';

fs.mkdirSync(env.articleUploadDir, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, env.articleUploadDir),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname || '').toLowerCase();
    cb(null, `${Date.now()}-${randomUUID()}${ext}`);
  },
});

function fileFilter(_req, file, cb) {
  const allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/jpg'];
  if (!allowed.includes(file.mimetype)) {
    return cb(new Error('Only jpg, jpeg, png and webp files are allowed'));
  }
  return cb(null, true);
}

export const uploadArticleImages = multer({
  storage,
  fileFilter,
  limits: {
    fileSize: env.maxUploadBytes,
    files: 10,
  },
});

function importFileFilter(_req, file, cb) {
  const allowedMimeTypes = [
    'text/csv',
    'application/csv',
    'application/vnd.ms-excel',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  ];

  const fileName = String(file.originalname || '').toLowerCase();
  const hasAllowedExtension = ['.csv', '.xlsx', '.xls'].some((extension) => fileName.endsWith(extension));

  if (!allowedMimeTypes.includes(file.mimetype) && !hasAllowedExtension) {
    return cb(new Error('Only csv, xls and xlsx files are allowed'));
  }

  return cb(null, true);
}

export const uploadArticleImportFile = multer({
  storage: multer.memoryStorage(),
  fileFilter: importFileFilter,
  limits: {
    fileSize: env.maxUploadBytes,
    files: 1,
  },
});
