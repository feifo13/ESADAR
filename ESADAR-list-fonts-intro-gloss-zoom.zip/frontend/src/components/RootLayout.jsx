import { Outlet, useLocation } from 'react-router-dom';
import { useEffect, useRef, useState } from 'react';
import Header from './Header.jsx';
import Footer from './Footer.jsx';
import ThemeDock from './ThemeDock.jsx';
import ScrollChrome from './ScrollChrome.jsx';
import esadarWordmark from '../assets/esadar-wordmark.png';

const INTRO_INITIAL_VISIBLE_MS = 3300;
const INTRO_INITIAL_FADE_MS = 650;
const INTRO_ROUTE_VISIBLE_MS = 960;
const INTRO_ROUTE_FADE_MS = 420;

export default function RootLayout() {
  const location = useLocation();
  const [heroLogoVisible, setHeroLogoVisible] = useState(false);
  const [introStage, setIntroStage] = useState('hidden');
  const [introKey, setIntroKey] = useState(0);
  const [introDuration, setIntroDuration] = useState(INTRO_INITIAL_VISIBLE_MS);
  const [introFadeDuration, setIntroFadeDuration] = useState(INTRO_INITIAL_FADE_MS);
  const isFirstIntro = useRef(true);
  const isHome = location.pathname === '/';
  const isCheckoutView = location.pathname.startsWith('/checkout');
  const isAdminView = location.pathname.startsWith('/admin');

  useEffect(() => {
    const reduceMotion =
      typeof window !== 'undefined' &&
      window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

    if (reduceMotion) {
      setIntroStage('hidden');
      return undefined;
    }

    const isInitialRun = isFirstIntro.current;
    isFirstIntro.current = false;

    const visibleMs = isInitialRun ? INTRO_INITIAL_VISIBLE_MS : INTRO_ROUTE_VISIBLE_MS;
    const fadeMs = isInitialRun ? INTRO_INITIAL_FADE_MS : INTRO_ROUTE_FADE_MS;

    setIntroDuration(visibleMs);
    setIntroFadeDuration(fadeMs);
    setIntroKey((current) => current + 1);
    setIntroStage('visible');

    const fadeTimer = window.setTimeout(() => setIntroStage('fading'), visibleMs);
    const hideTimer = window.setTimeout(() => setIntroStage('hidden'), visibleMs + fadeMs);

    return () => {
      window.clearTimeout(fadeTimer);
      window.clearTimeout(hideTimer);
    };
  }, [location.pathname]);

  const showIntro = introStage !== 'hidden';

  return (
    <div
      className={`app-shell${showIntro ? ' app-shell--intro-active' : ''}${isCheckoutView ? ' app-shell--checkout-view' : ''}${isAdminView ? ' app-shell--admin-view' : ''}`}
    >
      <Header hideBrand={isHome && heroLogoVisible} />
      <main className="page-shell">
        <div key={location.pathname} className="page-transition-shell">
          <Outlet context={{ setHeroLogoVisible }} />
        </div>
      </main>
      <Footer />
      <ThemeDock />
      <ScrollChrome />

      {showIntro ? (
        <div
          key={introKey}
          className={`intro-splash${introStage === 'fading' ? ' intro-splash--fade-out' : ''}`}
          style={{
            '--intro-logo-duration': `${introDuration}ms`,
            '--intro-fade-duration': `${introFadeDuration}ms`,
          }}
          aria-hidden="true"
        >
          <div className="intro-splash__logo-wrap">
            <img src={esadarWordmark} alt="" className="intro-splash__logo" />
          </div>
        </div>
      ) : null}
    </div>
  );
}
