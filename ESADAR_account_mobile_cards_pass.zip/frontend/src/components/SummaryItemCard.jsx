import { Link } from "react-router-dom";
import SmartImage from "./SmartImage.jsx";
import { cn } from "../lib/format.js";

export default function SummaryItemCard({
  className = "",
  image,
  imageAlt,
  imageFallbackLabel,
  imageTo,
  badge = null,
  title,
  titleTo,
  subtitle = null,
  meta = [],
  price = null,
  comparePrice = null,
  footer = null,
  actions = [],
}) {
  const MediaTag = imageTo ? Link : "div";
  const mediaProps = imageTo ? { to: imageTo } : {};
  const TitleTag = titleTo ? Link : "div";
  const titleProps = titleTo ? { to: titleTo } : {};

  return (
    <article
      className={cn(
        "summary-item-card",
        !image ? "summary-item-card--no-media" : "",
        className,
      )}
    >
      <div className="summary-item-card__main">
        {image ? (
          <MediaTag
            {...mediaProps}
            className={cn(
              "summary-item-card__media",
              imageTo ? "summary-item-card__media-link" : "",
            )}
            aria-label={imageTo ? `Ver ${title}` : undefined}
          >
            <SmartImage
              src={image}
              alt={imageAlt || title}
              fallbackLabel={imageFallbackLabel || title}
              className="summary-item-card__image"
            />
          </MediaTag>
        ) : null}

        <div className="summary-item-card__body">
          {badge ? <div className="summary-item-card__badge-row">{badge}</div> : null}

          <TitleTag
            {...titleProps}
            className={cn(
              "summary-item-card__title",
              titleTo ? "summary-item-card__title-link" : "",
            )}
          >
            {title}
          </TitleTag>

          {subtitle ? <p className="summary-item-card__subtitle">{subtitle}</p> : null}

          {meta.length ? (
            <div className="summary-item-card__meta">
              {meta.map((item, index) => (
                <div key={`${title}-meta-${index}`} className="summary-item-card__meta-line">
                  {item}
                </div>
              ))}
            </div>
          ) : null}

          {price != null || comparePrice != null ? (
            <div className="summary-item-card__price-block">
              {price != null ? <strong className="summary-item-card__price-current">{price}</strong> : null}
              {comparePrice != null ? (
                <span className="summary-item-card__price-compare">{comparePrice}</span>
              ) : null}
            </div>
          ) : null}

          {footer ? <div className="summary-item-card__footer">{footer}</div> : null}
        </div>
      </div>

      {actions.length ? (
        <div className="summary-item-card__actions">
          {actions.map((action, index) => (
            <div key={`${title}-action-${index}`} className="summary-item-card__action-slot">
              {action}
            </div>
          ))}
        </div>
      ) : null}
    </article>
  );
}
